/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.6",
   build: "0.10.0.134",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   content: {
         dom: [
         {
            id:'bike_background2',
            type:'image',
            rect:[0,0,753,610],
            opacity:1,
            fill:["rgba(0,0,0,0)",im+"bike_background2.gif"],
            transform:[[-2,-2]]
         },
         {
            id:'bike_background',
            type:'image',
            rect:[-2,-2,753,610],
            fill:["rgba(0,0,0,0)",im+"bike_background.png"],
            transform:[[-1,-1]]
         },
         {
            id:'car_nb_gray2',
            type:'image',
            rect:[932,501,100,70],
            fill:["rgba(0,0,0,0)",im+"car_nb_gray2.png"],
            transform:[[-294,-247]]
         },
         {
            id:'car_nb_light_blue2',
            type:'image',
            rect:[852,472,100,70],
            fill:["rgba(0,0,0,0)",im+"car_nb_light_blue2.png"],
            transform:[[-337,-142]]
         },
         {
            id:'car_nb_orange2',
            type:'image',
            rect:[948,464,100,70],
            fill:["rgba(0,0,0,0)",im+"car_nb_orange2.png"],
            transform:[[-699,17]]
         },
         {
            id:'car_sb_gray2',
            type:'image',
            rect:[922,456,100,70],
            fill:["rgba(0,0,0,0)",im+"car_sb_gray2.png"],
            transform:[[-244,-451]]
         },
         {
            id:'car_sb_gray2Copy',
            type:'image',
            rect:[922,456,100,70],
            fill:["rgba(0,0,0,0)",im+"car_sb_gray2.png"],
            transform:[[-909,-58]]
         },
         {
            id:'car_sb_green2',
            type:'image',
            rect:[932,456,100,70],
            fill:["rgba(0,0,0,0)",im+"car_sb_green2.png"],
            transform:[[-468,-329]]
         },
         {
            id:'car_sb_light_blue2',
            type:'image',
            rect:[856,411,100,70],
            fill:["rgba(0,0,0,0)",im+"car_sb_light_blue2.png"],
            transform:[[-696,-105]]
         },
         {
            id:'train_northbound',
            type:'image',
            rect:[882,513,440,300],
            fill:["rgba(0,0,0,0)",im+"train2.png"],
            transform:[[-1026,-118]]
         },
         {
            id:'train_southbound',
            type:'image',
            rect:[882,513,440,300],
            fill:["rgba(0,0,0,0)",im+"train2.png"],
            transform:[[-578,-459]]
         },
         {
            id:'Light_post_green2',
            type:'image',
            rect:[885,499,78,155],
            fill:["rgba(0,0,0,0)",im+"Light_post_green2.png"],
            transform:[[-302,-241]]
         },
         {
            id:'Light_post_back2',
            type:'image',
            rect:[838,485,105,170],
            fill:["rgba(0,0,0,0)",im+"Light_post_back2.png"],
            transform:[[-445,-113]]
         },
         {
            id:'RoundRect_carry',
            type:'rect',
            rect:[354,378,184,60],
            borderRadius:[10,10,"0px 0px",10],
            fill:["rgba(255,207,0,1)"],
            stroke:[1,"rgb(0, 0, 0)","solid"],
            transform:[[-1,-24]]
         },
         {
            id:'Text_carry',
            type:'text',
            rect:[388,384,163,43],
            text:"Carry repair tools, a spare inner tube, patches and a pump.",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',12,"rgba(0,0,0,1)","bold","none","normal"],
            transform:[[-24,-22]]
         },
         {
            id:'bubble_bubbles_carry',
            type:'image',
            rect:[852,427,203,90],
            fill:["rgba(0,0,0,0)",im+"bubble_bubbles.png"],
            transform:[[-499,-89]]
         },
         {
            id:'Text_carryCopy',
            type:'text',
            rect:[388,384,163,43],
            text:"Carry repair tools, a spare inner tube, patches and a pump.",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',12,"rgba(0,0,0,1)","bold","none","normal"],
            transform:[[-16,-39]]
         },
         {
            id:'bike_carry',
            type:'image',
            rect:[539,423,100,100],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"biker_updated_carry.png"],
            transform:[[-34,-36]]
         },
         {
            id:'bike_yield',
            type:'image',
            rect:[22,276,100,100],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"biker_updated_yield.png"],
            transform:[[-44,-48]]
         },
         {
            id:'RoundRect_yield',
            type:'rect',
            rect:[118,240,184,31],
            borderRadius:["0px 0px",10,10,10],
            fill:["rgba(255,207,0,1)"],
            stroke:[0,"rgb(0, 0, 0)","solid"],
            transform:[[-74,64]]
         },
         {
            id:'Text_yield',
            type:'text',
            rect:[67,327,0,0],
            text:"Always yield to pedestrians.",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',12,"rgba(0,0,0,1)","bold","none","normal"],
            transform:[[-10,-15]]
         },
         {
            id:'bike_direction',
            type:'image',
            rect:[231,244,100,100],
            clip:['rect(0px 80px 99px 0px)'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"biker_updated_direction.png"],
            transform:[[-61,-30]]
         },
         {
            id:'RoundRect_direction',
            type:'rect',
            rect:[15,175,182,44],
            borderRadius:["10px 10px",10,"0px 0px",10],
            fill:["rgba(255,207,0,1)"],
            stroke:[1,"rgb(0, 0, 0)","solid"],
            transform:[[7,15]]
         },
         {
            id:'Text_direction',
            type:'text',
            rect:[33,213,163,31],
            text:"Bike in the same direction as traffic.",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',12,"rgba(0,0,0,1)","bold","none","normal"],
            transform:[[-2,-14]]
         },
         {
            id:'bike_obey',
            type:'image',
            rect:[276,213,100,100],
            clip:['rect(0px 99px 99px 15px)'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"biker_updated_obey.png"],
            transform:[[-31,-36]]
         },
         {
            id:'RoundRect_obey',
            type:'rect',
            rect:[301,248,184,42],
            borderRadius:["0px 0px",10,"10px 10px",10],
            fill:["rgba(255,207,0,1)"],
            stroke:[1,"rgb(0, 0, 0)","solid"],
            transform:[[0,-2]]
         },
         {
            id:'Text_obey',
            type:'text',
            rect:[326,275,162,31],
            text:"Obey signs and signals at train crossings.",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',12,"rgba(0,0,0,1)","bold","none","normal"],
            transform:[[-14,-21]]
         },
         {
            id:'bike_attention',
            type:'image',
            rect:[236,520,100,100],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"biker_updated_attention.png"],
            transform:[[19,-3]]
         },
         {
            id:'RoundRect_attention',
            type:'rect',
            rect:[65,495,182,60],
            borderRadius:["10px 10px",10,"0px 0px",10],
            fill:["rgba(255,207,0,1)"],
            stroke:[1,"rgb(0, 0, 0)","solid"],
            transform:[[51,-11]]
         },
         {
            id:'Text_attention',
            type:'text',
            rect:[138,508,168,44],
            text:"Pay attention to vehicles that may enter your path at intersections and driveways.",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',12,"rgba(0,0,0,1)","bold","none","normal"],
            transform:[[-13,-16]]
         },
         {
            id:'bike_lights2',
            type:'image',
            rect:[819,367,100,100],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"biker_updated_lights.png"],
            transform:[[-156,-90]]
         },
         {
            id:'RoundRect_lights',
            type:'rect',
            rect:[518,246,182,42],
            borderRadius:["10px 10px",10,"0px 0px",10],
            fill:["rgba(255,207,0,1)"],
            stroke:[1,"rgb(0, 0, 0)","solid"],
            transform:[[5,14]]
         },
         {
            id:'Text_lights',
            type:'text',
            rect:[539,268,165,31],
            text:"Use lights, reflectors and wear reflective clothing.",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',12,"rgba(0,0,0,1)","bold","none","normal"],
            transform:[[-7]]
         },
         {
            id:'bike_avoid_hazards',
            type:'image',
            rect:[813,74,100,100],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"biker_hazards_updated.png"],
            transform:[[-210,-98]]
         },
         {
            id:'RoundRect_hazards',
            type:'rect',
            rect:[454,74,182,43],
            borderRadius:["10px 10px","0px 0px","10px 10px",10],
            fill:["rgba(255,207,0,1)"],
            stroke:[1,"rgb(0, 0, 0)","solid"],
            transform:[[0,-21]]
         },
         {
            id:'Text_hazards',
            type:'text',
            rect:[487,74,162,30],
            text:"Avoid road hazards such as sewer gates, road debris, manholes, ect. ",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',12,"rgba(0,0,0,1)","bold","none","normal"],
            transform:[[-23,-15]]
         },
         {
            id:'bike_wear_helmet',
            type:'image',
            rect:[901,436,100,100],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"biker_updated_helmet.png"],
            transform:[[-497,-347]]
         },
         {
            id:'RoundRect_helmetCopy',
            type:'rect',
            rect:[245,58,182,42],
            borderRadius:["10px 10px","10px 10px","0px 0px",10],
            fill:["rgba(0,0,0,1.00)"],
            stroke:[1,"rgb(0, 0, 0)","solid"],
            transform:[[7,13]]
         },
         {
            id:'RoundRect_helmet',
            type:'rect',
            rect:[245,58,182,42],
            borderRadius:["10px 10px","10px 10px","0px 0px",10],
            fill:["rgba(255,207,0,1)"],
            stroke:[1,"rgb(0, 0, 0)","solid"],
            transform:[[9,11]]
         },
         {
            id:'Text_helmet',
            type:'text',
            rect:[252,79,176,32],
            text:"Wear a helmet; it's required by law for persons under 18.",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',12.5,"rgba(0,0,0,1)","bold","none","normal"],
            transform:[[-4,-5]]
         },
         {
            id:'opening_scene_black_stage',
            type:'rect',
            rect:[-2,-8,752,609],
            opacity:0.65,
            fill:["rgba(0,0,0,1.00)"],
            stroke:[0,"rgb(0, 0, 0)","none"]
         },
         {
            id:'opening_play_button3',
            type:'image',
            rect:[870,485,64,64],
            fill:["rgba(0,0,0,0)",im+"opening_play_button.png"],
            transform:[[-530,-219]]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_bike_obey}": [
            ["transform", "translateX", '-31.4px'],
            ["style", "cursor", 'pointer'],
            ["style", "clip", [0,99,99,15], {valueTemplate:'rect(@@0@@px @@1@@px @@2@@px @@3@@px)'} ],
            ["transform", "translateY", '-36.4px']
         ],
         "${_bubble_bubbles_carry}": [
            ["style", "-webkit-transform-origin", [100,100], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "translateX", '-499px'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-89px'],
            ["transform", "scaleY", '0']
         ],
         "${_Text_obey}": [
            ["transform", "translateX", '-14.2px'],
            ["style", "height", '31px'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-21.8px'],
            ["style", "width", '162px']
         ],
         "${_car_sb_green2}": [
            ["transform", "translateX", '-258.2px'],
            ["transform", "translateY", '-448.39px']
         ],
         "${_bike_background2}": [
            ["style", "opacity", '1'],
            ["transform", "translateX", '-2px'],
            ["transform", "translateY", '-2px']
         ],
         "${_bike_avoid_hazards}": [
            ["style", "cursor", 'pointer'],
            ["transform", "translateY", '-98.2px'],
            ["transform", "translateX", '-210.4px']
         ],
         "${_Text_attention}": [
            ["transform", "translateX", '-13px'],
            ["style", "height", '44px'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-16.39px'],
            ["style", "width", '168px']
         ],
         "${_opening_scene_black_stage}": [
            ["color", "background-color", 'rgba(0,0,0,1.00)'],
            ["style", "opacity", '0.6499999761581421'],
            ["style", "display", 'block']
         ],
         "${_RoundRect_obey}": [
            ["style", "-webkit-transform-origin", [0,0], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [0,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [0,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [0,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [0,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "border-top-left-radius", [0,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-bottom-right-radius", [10,10], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["transform", "scaleX", '0'],
            ["style", "border-style", 'solid'],
            ["style", "border-width", '1px'],
            ["style", "width", '184px'],
            ["transform", "scaleY", '0'],
            ["style", "height", '42px'],
            ["transform", "translateY", '-2px'],
            ["style", "opacity", '0']
         ],
         "${_bike_direction}": [
            ["transform", "translateX", '-61.4px'],
            ["style", "cursor", 'pointer'],
            ["style", "clip", [0,80,99,0], {valueTemplate:'rect(@@0@@px @@1@@px @@2@@px @@3@@px)'} ],
            ["transform", "translateY", '-30.6px']
         ],
         "${_bike_background}": [
            ["transform", "translateY", '-1px'],
            ["transform", "translateX", '-1px']
         ],
         "${_RoundRect_hazards}": [
            ["style", "-webkit-transform-origin", [100,0], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [100,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [100,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [100,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [100,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "translateX", '-0.61px'],
            ["style", "border-bottom-right-radius", [10,10], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["transform", "scaleX", '0'],
            ["style", "border-style", 'solid'],
            ["style", "border-top-right-radius", [0,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "width", '182px'],
            ["transform", "scaleY", '0'],
            ["style", "height", '58px'],
            ["style", "border-width", '1px'],
            ["transform", "translateY", '-21.2px'],
            ["style", "opacity", '0']
         ],
         "${_bike_attention}": [
            ["style", "cursor", 'pointer'],
            ["transform", "translateY", '-3.4px'],
            ["transform", "translateX", '19.79px']
         ],
         "${_car_nb_light_blue2}": [
            ["transform", "translateX", '-584.2px'],
            ["transform", "translateY", '-0.6px']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(0,0,0,0.00)'],
            ["style", "height", '600px'],
            ["style", "width", '750px']
         ],
         "${_RoundRect_helmetCopy}": [
            ["style", "-webkit-transform-origin", [100,100], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "translateX", '7px'],
            ["style", "border-bottom-right-radius", [0,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["transform", "scaleX", '0'],
            ["style", "border-style", 'solid'],
            ["style", "border-width", '1px'],
            ["style", "width", '182px'],
            ["transform", "scaleY", '0'],
            ["color", "background-color", 'rgba(0,0,0,1.00)'],
            ["style", "height", '42px'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '13px'],
            ["style", "border-top-right-radius", [10,10], {valueTemplate:'@@0@@px @@1@@px'} ]
         ],
         "${_train_northbound}": [
            ["transform", "translateX", '-1321px'],
            ["transform", "translateY", '53.59px']
         ],
         "${_Light_post_back2}": [
            ["transform", "translateX", '-445.6px'],
            ["transform", "translateY", '-113.8px']
         ],
         "${_Light_post_green2}": [
            ["transform", "translateX", '-302.4px'],
            ["transform", "translateY", '-241px']
         ],
         "${_RoundRect_helmet}": [
            ["style", "-webkit-transform-origin", [100,100], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "translateX", '9px'],
            ["style", "border-bottom-right-radius", [0,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["transform", "scaleX", '0'],
            ["style", "border-style", 'solid'],
            ["style", "border-top-right-radius", [10,10], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "width", '182px'],
            ["transform", "scaleY", '0'],
            ["style", "height", '42px'],
            ["style", "border-width", '1px'],
            ["transform", "translateY", '11px'],
            ["style", "opacity", '0']
         ],
         "${_bike_yield}": [
            ["transform", "translateX", '-44.4px'],
            ["transform", "translateY", '-48.4px'],
            ["style", "cursor", 'pointer']
         ],
         "${_Text_hazards}": [
            ["transform", "translateX", '-23px'],
            ["style", "height", '30px'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-15.2px'],
            ["style", "width", '162px']
         ],
         "${_RoundRect_direction}": [
            ["style", "-webkit-transform-origin", [100,100], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "border-top-left-radius", [10,10], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["transform", "translateX", '7px'],
            ["style", "border-bottom-right-radius", [0,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["transform", "scaleX", '0'],
            ["style", "border-style", 'solid'],
            ["style", "border-width", '1px'],
            ["style", "width", '182px'],
            ["transform", "scaleY", '0'],
            ["transform", "translateY", '15px'],
            ["style", "opacity", '0']
         ],
         "${_car_sb_gray2Copy}": [
            ["transform", "translateX", '-699.6px'],
            ["transform", "translateY", '-177.39px']
         ],
         "${_car_sb_gray2}": [
            ["transform", "translateX", '-34.99px'],
            ["transform", "translateY", '-570.39px']
         ],
         "${_RoundRect_carry}": [
            ["style", "-webkit-transform-origin", [100,100], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "translateX", '-1.19px'],
            ["style", "border-bottom-right-radius", [0,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '0'],
            ["style", "border-width", '1px'],
            ["style", "width", '184px'],
            ["transform", "scaleY", '0'],
            ["style", "overflow", 'visible'],
            ["style", "height", '60px'],
            ["transform", "translateY", '-24px'],
            ["style", "border-style", 'solid']
         ],
         "${_bike_lights2}": [
            ["style", "cursor", 'pointer'],
            ["transform", "translateY", '-90px'],
            ["transform", "translateX", '-156.19px']
         ],
         "${_bike_wear_helmet}": [
            ["style", "cursor", 'pointer'],
            ["transform", "translateY", '-347.6px'],
            ["transform", "translateX", '-497px']
         ],
         "${_Text_carry}": [
            ["style", "width", '163px'],
            ["style", "font-weight", 'bold'],
            ["transform", "translateX", '-24.28px'],
            ["style", "overflow", 'visible'],
            ["style", "height", '43px'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-22.5px'],
            ["style", "font-size", '12px']
         ],
         "${_Text_yield}": [
            ["transform", "translateY", '-15px'],
            ["style", "font-weight", 'bold'],
            ["transform", "translateX", '-10px'],
            ["style", "opacity", '0']
         ],
         "${_RoundRect_yield}": [
            ["style", "-webkit-transform-origin", [0,0], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [0,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [0,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [0,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [0,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "border-top-left-radius", [0,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["transform", "translateX", '-74px'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '0'],
            ["style", "border-width", '1px'],
            ["style", "width", '184px'],
            ["transform", "scaleY", '0'],
            ["style", "height", '31px'],
            ["transform", "translateY", '64.98px'],
            ["style", "border-style", 'solid']
         ],
         "${_car_nb_orange2}": [
            ["transform", "translateX", '-892px'],
            ["transform", "translateY", '136.79px']
         ],
         "${_car_sb_light_blue2}": [
            ["transform", "translateX", '-486.6px'],
            ["transform", "translateY", '-224.79px']
         ],
         "${_RoundRect_attention}": [
            ["style", "-webkit-transform-origin", [100,100], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "border-top-left-radius", [10,10], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["transform", "translateX", '51px'],
            ["style", "border-bottom-right-radius", [0,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["transform", "scaleX", '0'],
            ["style", "border-style", 'solid'],
            ["style", "border-width", '1px'],
            ["style", "width", '182px'],
            ["transform", "scaleY", '0'],
            ["style", "height", '60px'],
            ["transform", "translateY", '-11px'],
            ["style", "opacity", '0']
         ],
         "${_bike_carry}": [
            ["transform", "translateX", '-34.6px'],
            ["transform", "translateY", '-36.4px'],
            ["style", "cursor", 'pointer']
         ],
         "${_car_nb_gray2}": [
            ["transform", "translateX", '-537.2px'],
            ["transform", "translateY", '-96.4px']
         ],
         "${_Text_direction}": [
            ["transform", "translateX", '-2px'],
            ["style", "height", '31px'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-14.5px'],
            ["style", "width", '163px']
         ],
         "${_train_southbound}": [
            ["transform", "translateX", '-132px'],
            ["transform", "translateY", '-717.4px']
         ],
         "${_Text_lights}": [
            ["transform", "translateX", '-7px'],
            ["style", "height", '31px'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-0.5px'],
            ["style", "width", '165px']
         ],
         "${_RoundRect_lights}": [
            ["style", "-webkit-transform-origin", [100,100], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "translateX", '5px'],
            ["transform", "scaleX", '0'],
            ["style", "border-style", 'solid'],
            ["style", "border-width", '1px'],
            ["style", "width", '182px'],
            ["transform", "scaleY", '0'],
            ["style", "height", '42px'],
            ["transform", "translateY", '14px'],
            ["style", "opacity", '0']
         ],
         "${_opening_play_button3}": [
            ["style", "-webkit-transform-origin", [50,50], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "translateX", '-530px'],
            ["transform", "translateY", '-219.8px'],
            ["transform", "scaleX", '1']
         ],
         "${_Text_helmet}": [
            ["style", "font-size", '12.5px'],
            ["style", "text-decoration", 'none'],
            ["transform", "translateX", '-4.5px'],
            ["style", "font-weight", 'bold'],
            ["style", "height", '32px'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-5.5px'],
            ["style", "width", '176px']
         ],
         "${_Text_carryCopy}": [
            ["style", "font-size", '12px'],
            ["style", "opacity", '0'],
            ["transform", "translateX", '-16.6px'],
            ["style", "overflow", 'visible'],
            ["style", "height", '43px'],
            ["style", "font-weight", 'bold'],
            ["transform", "translateY", '-39px'],
            ["style", "width", '163px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 18740,
         autoPlay: true,
         labels: {
            "motion": 250,
            "begining": 3500,
            "carry": 4990,
            "yield": 6745,
            "direction": 8490,
            "obey": 10240,
            "attention": 11990,
            "lights": 13740,
            "hazards": 15490,
            "helmet": 17240
         },
         timeline: [
            { id: "eid24", tween: [ "style", "${_RoundRect_yield}", "opacity", '1', { fromValue: '0'}], position: 6745, duration: 1000, easing: "easeOutBack" },
            { id: "eid45", tween: [ "transform", "${_RoundRect_obey}", "scaleX", '1', { fromValue: '0'}], position: 10240, duration: 1000, easing: "easeOutBack" },
            { id: "eid199", tween: [ "transform", "${_car_sb_light_blue2}", "translateX", '-696.6px', { fromValue: '-486.6px'}], position: 1000, duration: 2000 },
            { id: "eid281", tween: [ "transform", "${_opening_play_button3}", "scaleX", '0', { fromValue: '1'}], position: 100, duration: 150 },
            { id: "eid282", tween: [ "transform", "${_opening_play_button3}", "scaleX", '0', { fromValue: '1'}], position: 250, duration: 250 },
            { id: "eid181", tween: [ "transform", "${_car_nb_orange2}", "translateX", '-699px', { fromValue: '-892px'}], position: 1000, duration: 2000 },
            { id: "eid31", tween: [ "transform", "${_RoundRect_direction}", "scaleY", '1', { fromValue: '0'}], position: 8490, duration: 1000, easing: "easeOutBack" },
            { id: "eid51", tween: [ "transform", "${_RoundRect_attention}", "scaleX", '1', { fromValue: '0'}], position: 11990, duration: 1000, easing: "easeOutBack" },
            { id: "eid86", tween: [ "style", "${_RoundRect_hazards}", "opacity", '1', { fromValue: '0'}], position: 15490, duration: 1000, easing: "easeOutBack" },
            { id: "eid29", tween: [ "transform", "${_RoundRect_direction}", "scaleX", '1', { fromValue: '0'}], position: 8490, duration: 1000, easing: "easeOutBack" },
            { id: "eid2", tween: [ "style", "${_RoundRect_carry}", "opacity", '1', { fromValue: '0'}], position: 4990, duration: 1005, easing: "easeOutBack" },
            { id: "eid88", tween: [ "transform", "${_RoundRect_hazards}", "scaleX", '1', { fromValue: '0'}], position: 15490, duration: 1000, easing: "easeOutBack" },
            { id: "eid314", tween: [ "style", "${_bubble_bubbles_carry}", "opacity", '1', { fromValue: '0'}], position: 4990, duration: 1005, easing: "easeInOutBack" },
            { id: "eid191", tween: [ "transform", "${_car_nb_light_blue2}", "translateX", '-337px', { fromValue: '-584.2px'}], position: 1000, duration: 2000 },
            { id: "eid211", tween: [ "transform", "${_car_sb_gray2}", "translateX", '-244.99px', { fromValue: '-34.99px'}], position: 1000, duration: 2000 },
            { id: "eid25", tween: [ "style", "${_RoundRect_yield}", "border-width", '1px', { fromValue: '1px'}], position: 7745, duration: 0 },
            { id: "eid47", tween: [ "transform", "${_RoundRect_obey}", "scaleY", '1', { fromValue: '0'}], position: 10240, duration: 1000, easing: "easeOutBack" },
            { id: "eid27", tween: [ "style", "${_Text_yield}", "opacity", '1', { fromValue: '0'}], position: 7615, duration: 630 },
            { id: "eid207", tween: [ "transform", "${_car_sb_gray2Copy}", "translateX", '-909.6px', { fromValue: '-699.6px'}], position: 1000, duration: 2000 },
            { id: "eid63", tween: [ "style", "${_RoundRect_lights}", "opacity", '1', { fromValue: '0'}], position: 13740, duration: 1000, easing: "easeOutBack" },
            { id: "eid193", tween: [ "transform", "${_car_nb_light_blue2}", "translateY", '-142.6px', { fromValue: '-0.6px'}], position: 1000, duration: 2000 },
            { id: "eid201", tween: [ "transform", "${_car_sb_light_blue2}", "translateY", '-105.4px', { fromValue: '-224.79px'}], position: 1000, duration: 2000 },
            { id: "eid79", tween: [ "transform", "${_RoundRect_helmet}", "scaleX", '1.09', { fromValue: '0'}], position: 17240, duration: 1000, easing: "easeOutBack" },
            { id: "eid85", tween: [ "style", "${_Text_helmet}", "opacity", '1', { fromValue: '0'}], position: 18175, duration: 565 },
            { id: "eid107", tween: [ "transform", "${_RoundRect_helmetCopy}", "scaleY", '1.09', { fromValue: '0'}], position: 17240, duration: 1000, easing: "easeOutBack" },
            { id: "eid65", tween: [ "style", "${_Text_lights}", "opacity", '1', { fromValue: '0'}], position: 14675, duration: 565 },
            { id: "eid81", tween: [ "transform", "${_RoundRect_helmet}", "scaleY", '1.09', { fromValue: '0'}], position: 17240, duration: 1000, easing: "easeOutBack" },
            { id: "eid3", tween: [ "transform", "${_RoundRect_carry}", "scaleX", '1', { fromValue: '0'}], position: 4990, duration: 1005, easing: "easeOutBack" },
            { id: "eid274", tween: [ "style", "${_opening_scene_black_stage}", "opacity", '0', { fromValue: '0.6499999761581421'}], position: 250, duration: 750 },
            { id: "eid312", tween: [ "transform", "${_bubble_bubbles_carry}", "scaleY", '1', { fromValue: '0'}], position: 4990, duration: 1005, easing: "easeInOutBack" },
            { id: "eid213", tween: [ "transform", "${_car_sb_gray2}", "translateY", '-451px', { fromValue: '-570.39px'}], position: 1000, duration: 2000 },
            { id: "eid175", tween: [ "transform", "${_train_southbound}", "translateY", '-459.4px', { fromValue: '-717.4px'}], position: 1000, duration: 2000 },
            { id: "eid1", tween: [ "style", "${_Text_carry}", "opacity", '1', { fromValue: '0'}], position: 5885, duration: 610 },
            { id: "eid53", tween: [ "transform", "${_RoundRect_attention}", "scaleY", '1', { fromValue: '0'}], position: 11990, duration: 1000, easing: "easeOutBack" },
            { id: "eid55", tween: [ "style", "${_RoundRect_attention}", "opacity", '1', { fromValue: '0'}], position: 11990, duration: 1000, easing: "easeOutBack" },
            { id: "eid108", tween: [ "style", "${_RoundRect_helmetCopy}", "opacity", '0.19325222013748', { fromValue: '0'}], position: 17240, duration: 195, easing: "easeOutBack" },
            { id: "eid109", tween: [ "style", "${_RoundRect_helmetCopy}", "opacity", '0.24657526632694', { fromValue: '0.19325222013748'}], position: 17435, duration: 805, easing: "easeOutBack" },
            { id: "eid83", tween: [ "style", "${_RoundRect_helmet}", "opacity", '1', { fromValue: '0'}], position: 17240, duration: 1000, easing: "easeOutBack" },
            { id: "eid59", tween: [ "transform", "${_RoundRect_lights}", "scaleX", '1', { fromValue: '0'}], position: 13740, duration: 1000, easing: "easeOutBack" },
            { id: "eid173", tween: [ "transform", "${_train_southbound}", "translateX", '-578px', { fromValue: '-132px'}], position: 1000, duration: 2000 },
            { id: "eid177", tween: [ "transform", "${_train_northbound}", "translateX", '-1026px', { fromValue: '-1321px'}], position: 1000, duration: 2000 },
            { id: "eid209", tween: [ "transform", "${_car_sb_gray2Copy}", "translateY", '-58px', { fromValue: '-177.39px'}], position: 1000, duration: 2000 },
            { id: "eid89", tween: [ "style", "${_RoundRect_hazards}", "height", '58px', { fromValue: '58px'}], position: 14950, duration: 0 },
            { id: "eid43", tween: [ "style", "${_RoundRect_obey}", "opacity", '1', { fromValue: '0'}], position: 10240, duration: 1000, easing: "easeOutBack" },
            { id: "eid87", tween: [ "transform", "${_RoundRect_hazards}", "scaleY", '1', { fromValue: '0'}], position: 15490, duration: 1000, easing: "easeOutBack" },
            { id: "eid197", tween: [ "transform", "${_car_nb_gray2}", "translateY", '-247.2px', { fromValue: '-96.4px'}], position: 1000, duration: 2000 },
            { id: "eid195", tween: [ "transform", "${_car_nb_gray2}", "translateX", '-294.2px', { fromValue: '-537.2px'}], position: 1000, duration: 2000 },
            { id: "eid316", tween: [ "style", "${_Text_carryCopy}", "opacity", '1', { fromValue: '0'}], position: 5885, duration: 610 },
            { id: "eid33", tween: [ "style", "${_RoundRect_direction}", "opacity", '1', { fromValue: '0'}], position: 8490, duration: 1000, easing: "easeOutBack" },
            { id: "eid35", tween: [ "style", "${_Text_direction}", "opacity", '1', { fromValue: '0'}], position: 9345, duration: 645 },
            { id: "eid183", tween: [ "transform", "${_car_nb_orange2}", "translateY", '17.79px', { fromValue: '136.79px'}], position: 1000, duration: 2000 },
            { id: "eid205", tween: [ "transform", "${_car_sb_green2}", "translateY", '-329px', { fromValue: '-448.39px'}], position: 1000, duration: 2000 },
            { id: "eid73", tween: [ "style", "${_Text_hazards}", "opacity", '1', { fromValue: '0'}], position: 16380, duration: 610 },
            { id: "eid4", tween: [ "transform", "${_RoundRect_carry}", "scaleY", '1', { fromValue: '0'}], position: 4990, duration: 1005, easing: "easeOutBack" },
            { id: "eid106", tween: [ "transform", "${_RoundRect_helmetCopy}", "scaleX", '1.09', { fromValue: '0'}], position: 17240, duration: 1000, easing: "easeOutBack" },
            { id: "eid269", tween: [ "style", "${_opening_scene_black_stage}", "display", 'none', { fromValue: 'block'}], position: 1000, duration: 0 },
            { id: "eid57", tween: [ "style", "${_Text_attention}", "opacity", '1', { fromValue: '0'}], position: 12895, duration: 595 },
            { id: "eid310", tween: [ "transform", "${_bubble_bubbles_carry}", "scaleX", '1', { fromValue: '0'}], position: 4990, duration: 1005, easing: "easeInOutBack" },
            { id: "eid22", tween: [ "transform", "${_RoundRect_yield}", "scaleY", '1', { fromValue: '0'}], position: 6745, duration: 1000, easing: "easeOutBack" },
            { id: "eid179", tween: [ "transform", "${_train_northbound}", "translateY", '-118.4px', { fromValue: '53.59px'}], position: 1000, duration: 2000 },
            { id: "eid49", tween: [ "style", "${_Text_obey}", "opacity", '1', { fromValue: '0'}], position: 11130, duration: 610 },
            { id: "eid270", tween: [ "color", "${_opening_scene_black_stage}", "background-color", 'rgba(0,0,0,1.00)', { animationColorSpace: 'RGB', valueTemplate: undefined, fromValue: 'rgba(0,0,0,1.00)'}], position: 250, duration: 0 },
            { id: "eid61", tween: [ "transform", "${_RoundRect_lights}", "scaleY", '1', { fromValue: '0'}], position: 13740, duration: 1000, easing: "easeOutBack" },
            { id: "eid203", tween: [ "transform", "${_car_sb_green2}", "translateX", '-468.2px', { fromValue: '-258.2px'}], position: 1000, duration: 2000 },
            { id: "eid20", tween: [ "transform", "${_RoundRect_yield}", "scaleX", '1', { fromValue: '0'}], position: 6745, duration: 1000, easing: "easeOutBack" }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-1752384041");
