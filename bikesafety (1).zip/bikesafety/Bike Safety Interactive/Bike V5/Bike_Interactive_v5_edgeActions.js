/***********************
* Adobe Edge Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

   //Edge symbol: 'stage'
   (function(symbolName) {
      
      
      

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 8150, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bike_carry}", "mouseup", function(sym, e) {
         // insert code to be run when the mouse button is released
         // play the timeline from the given position (ms or label)
         sym.play("carry");

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bike_yield}", "mouseup", function(sym, e) {
         // insert code to be run when the mouse button is released
         // play the timeline from the given position (ms or label)
         sym.play("yield");

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 6445, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 9940, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bike_direction}", "mouseup", function(sym, e) {
         // insert code to be run when the mouse button is released
         // play the timeline from the given position (ms or label)
         sym.play("direction");

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 11690, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 13445, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bike_attention}", "mouseup", function(sym, e) {
         // insert code to be run when the mouse button is released
         // play the timeline from the given position (ms or label)
         sym.play("attention");

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 15195, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bike_lights2}", "mouseup", function(sym, e) {
         // insert code to be run when the mouse button is released
         // play the timeline from the given position (ms or label)
         sym.play("lights");

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 16940, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bike_avoid_hazards}", "mouseup", function(sym, e) {
         // insert code to be run when the mouse button is released
         // play the timeline from the given position (ms or label)
         sym.play("hazards");

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 18680, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bike_wear_helmet}", "mouseup", function(sym, e) {
         // insert code to be run when the mouse button is released
         // play the timeline from the given position (ms or label)
         sym.play("helmet");

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bike_obey}", "mouseup", function(sym, e) {
         // insert code to be run when the mouse button is released
         // play the timeline from the given position (ms or label)
         sym.play("obey");

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 4770, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 250, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 3250, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_opening_play_button3}", "mouseup", function(sym, e) {
         // insert code to be run when the mouse button is released
         // play the timeline from the given position (ms or label)
         sym.play("motion");

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 100, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

   })("stage");
   //Edge symbol end:'stage'

})(jQuery, AdobeEdge, "EDGE-1752384041");