/***********************
* Adobe Edge Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

   //Edge symbol: 'stage'
   (function(symbolName) {
      
      
      

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 11500, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bike_carry}", "mouseup", function(sym, e) {
         // insert code to be run when the mouse button is released
         // play the timeline from the given position (ms or label)
         sym.play("carry");

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bike_yield}", "mouseup", function(sym, e) {
         // insert code to be run when the mouse button is released
         // play the timeline from the given position (ms or label)
         sym.play("yield");

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 9750, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 13250, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bike_direction}", "mouseup", function(sym, e) {
         // insert code to be run when the mouse button is released
         // play the timeline from the given position (ms or label)
         sym.play("direction");

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 15000, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 16750, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bike_attention}", "mouseup", function(sym, e) {
         // insert code to be run when the mouse button is released
         // play the timeline from the given position (ms or label)
         sym.play("attention");

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 18495, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bike_lights2}", "mouseup", function(sym, e) {
         // insert code to be run when the mouse button is released
         // play the timeline from the given position (ms or label)
         sym.play("lights");

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 20200, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bike_avoid_hazards}", "mouseup", function(sym, e) {
         // insert code to be run when the mouse button is released
         // play the timeline from the given position (ms or label)
         sym.play("hazards");

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 21879, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bike_wear_helmet}", "mouseup", function(sym, e) {
         // insert code to be run when the mouse button is released
         // play the timeline from the given position (ms or label)
         sym.play("helmet");

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bike_obey}", "mouseup", function(sym, e) {
         // insert code to be run when the mouse button is released
         // play the timeline from the given position (ms or label)
         sym.play("obey");

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 8030, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 7185, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      

      

      

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 7500, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      

      

      

      

      

      

      

      

      Symbol.bindElementAction(compId, symbolName, "${_close_button_hazards}", "click", function(sym, e) {
         // insert code for mouse click here
         // play the timeline from the given position (ms or label)
         sym.play("begining");
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_close_button_helmet}", "click", function(sym, e) {
         // insert code for mouse click here
         // play the timeline from the given position (ms or label)
         sym.play("begining");
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_close_button_lights}", "click", function(sym, e) {
         // insert code for mouse click here
         // play the timeline from the given position (ms or label)
         sym.play("begining");
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_close_button_attention}", "click", function(sym, e) {
         // insert code for mouse click here
         // play the timeline from the given position (ms or label)
         sym.play("begining");
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_close_button_obey}", "click", function(sym, e) {
         // insert code for mouse click here
         // play the timeline from the given position (ms or label)
         sym.play("begining");
         

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 13250, function(sym, e) {
         // insert code here
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_close_button_direction}", "click", function(sym, e) {
         // insert code for mouse click here
         // play the timeline from the given position (ms or label)
         sym.play("begining");
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_close_button_yield}", "click", function(sym, e) {
         // insert code for mouse click here
         // play the timeline from the given position (ms or label)
         sym.play("begining");
         

      });
      //Edge binding end

      

      Symbol.bindElementAction(compId, symbolName, "${_close_button_carry}", "click", function(sym, e) {
         // insert code for mouse click here
         // play the timeline from the given position (ms or label)
         sym.play("begining");

      });
      //Edge binding end

      

      

      

      

      

      

      

      Symbol.bindElementAction(compId, symbolName, "${_refresh_solid}", "click", function(sym, e) {
         // insert code for mouse click here
         // play the timeline from the given position (ms or label)
         sym.play("motionstart");

      });
      //Edge binding end

   })("stage");
   //Edge symbol end:'stage'

//=========================================================
   //Edge symbol: 'hotspot'
   (function(symbolName) {

      

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 21000, function(sym, e) {
         // insert code here
         // play the timeline from the given position (ms or label)
         sym.play("hotspot");

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 1250, function(sym, e) {
         // insert code here
         // play the timeline from the given position (ms or label)
         sym.play("hotspot");

      });
      //Edge binding end

   })("hotspot");
   //Edge symbol end:'hotspot'

//=========================================================
   (function(symbolName) {

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 2000, function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play("station");
         // insert code here

      });
      //Edge binding end

   })("Symbol_park");
   //Edge symbol end:'Symbol_park'

//=========================================================
   (function(symbolName) {

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 5760, function(sym, e) {
         // insert code here
      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 7000, function(sym, e) {
         // insert code here
         // play the timeline from the given position (ms or label)
         sym.play("backlight");

      });
      //Edge binding end

   })("Symbol_backlight");
   //Edge symbol end:'Symbol_backlight'

//=========================================================
   (function(symbolName) {

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 7250, function(sym, e) {
         // insert code here
         // play the timeline from the given position (ms or label)
         sym.play("frontlight");

      });
      //Edge binding end

   })("Symbol_frontlight");
   //Edge symbol end:'Symbol_frontlight'

//=========================================================
   (function(symbolName) {

   })("Symbol_blick");
   //Edge symbol end:'Symbol_blick'

//=========================================================
   (function(symbolName) {

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 2000, function(sym, e) {
         // insert code here
         // play the timeline from the given position (ms or label)
         sym.play("orangestart");

      });
      //Edge binding end

   })("Symbol_park_orange");
   //Edge symbol end:'Symbol_park_orange'

//=========================================================
   (function(symbolName) {

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 2000, function(sym, e) {
         // insert code here
         // play the timeline from the given position (ms or label)
         sym.play("redstart");

      });
      //Edge binding end

   })("Symbol_park_red");
   //Edge symbol end:'Symbol_park_red'

})(jQuery, AdobeEdge, "EDGE-1752384041");