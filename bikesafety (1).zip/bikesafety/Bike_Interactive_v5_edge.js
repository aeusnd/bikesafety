/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.6",
   build: "0.10.0.134",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   content: {
         dom: [
         {
            id:'bike_background',
            type:'image',
            rect:[-2,-2,753,610],
            fill:["rgba(0,0,0,0)",im+"bike_background_rev.png"],
            transform:[[0,-1]]
         },
         {
            id:'bike_backgroundCopy',
            type:'image',
            rect:[-2,-2,753,610],
            fill:["rgba(0,0,0,0)",im+"bike_background_final.png"],
            transform:[[0,-1]]
         },
         {
            id:'car_nb_gray2',
            type:'image',
            rect:[932,501,100,70],
            fill:["rgba(0,0,0,0)",im+"cars_nb_v2_orange.png"],
            transform:[[-291,-250]]
         },
         {
            id:'car_nb_light_blue2',
            type:'image',
            rect:[852,472,100,70],
            fill:["rgba(0,0,0,0)",im+"cars_nb_v2_blue.png"],
            transform:[[-338,-154]]
         },
         {
            id:'car_nb_orange2',
            type:'image',
            rect:[948,464,100,70],
            fill:["rgba(0,0,0,0)",im+"cars_nb_v2_orange.png"],
            transform:[[-646,-17]]
         },
         {
            id:'car_sb_gray2',
            type:'image',
            rect:[922,456,100,70],
            fill:["rgba(0,0,0,0)",im+"cars_sb_v2_blue2.png"],
            transform:[[-259,-440]]
         },
         {
            id:'car_sb_gray2Copy',
            type:'image',
            rect:[922,456,100,70],
            fill:["rgba(0,0,0,0)",im+"cars_sb_v2_green.png"],
            transform:[[-924,-47]]
         },
         {
            id:'car_sb_green2',
            type:'image',
            rect:[932,456,100,70],
            fill:["rgba(0,0,0,0)",im+"cars_sb_v2_green.png"],
            transform:[[-482,-318]]
         },
         {
            id:'car_sb_light_blue2',
            type:'image',
            rect:[856,411,100,70],
            fill:["rgba(0,0,0,0)",im+"cars_sb_v2_blue.png"],
            transform:[[-711,-94]]
         },
         {
            id:'train_southbound_first',
            type:'image',
            rect:[882,513,440,300],
            fill:["rgba(0,0,0,0)",im+"rail_v3.png"],
            transform:[[-1321,-27]]
         },
         {
            id:'train_southbound_second',
            type:'image',
            rect:[882,513,440,300],
            fill:["rgba(0,0,0,0)",im+"rail_v3.png"],
            transform:[[-581,-454]]
         },
         {
            id:'train_northbound_first',
            type:'image',
            rect:[882,513,440,300],
            fill:["rgba(0,0,0,0)",im+"rail_v3.png"],
            transform:[[-132,-627]]
         },
         {
            id:'train_northbound_second',
            type:'image',
            rect:[882,513,440,300],
            fill:["rgba(0,0,0,0)",im+"rail_v3.png"],
            transform:[[-1026,-118]]
         },
         {
            id:'Symbol_carry',
            type:'rect',
            rect:[272,550,0,0]
         },
         {
            id:'bike_carry',
            type:'image',
            rect:[539,423,100,100],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"biker_updated_carry.png"],
            transform:[[-35,-34]]
         },
         {
            id:'Symbol_lights',
            type:'rect',
            rect:[272,550,0,0]
         },
         {
            id:'bike_lights2',
            type:'image',
            rect:[819,367,100,100],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"biker_updated_lights.png"],
            transform:[[-155,-90]]
         },
         {
            id:'Symbol_park_orange',
            type:'rect',
            rect:[861,499,0,0]
         },
         {
            id:'Light_post_back2',
            type:'image',
            rect:[838,485,105,170],
            fill:["rgba(0,0,0,0)",im+"Light_post_back2.png"],
            transform:[[-446,-114]]
         },
         {
            id:'Light_post_green2',
            type:'image',
            rect:[885,499,78,155],
            fill:["rgba(0,0,0,0)",im+"Light_post_green2.png"],
            transform:[[-302,-241]]
         },
         {
            id:'message_bulbble_carry',
            type:'image',
            rect:[829,482,250,125],
            fill:["rgba(0,0,0,0)",im+"message_bulbble_carry.png"],
            transform:[[-527,-177]]
         },
         {
            id:'Text_carry',
            type:'text',
            rect:[-144,329,150,44],
            text:"Carry repair tools, a spare inner tube, patches and a pump.",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',13,"rgba(0,0,0,1)","bold","none","normal"],
            transform:[[512,16]]
         },
         {
            id:'close_button_carry',
            type:'image',
            rect:[824,409,24,24],
            cursor:['pointer'],
            opacity:1,
            fill:["rgba(0,0,0,0)",im+"close_updated.png"],
            transform:[[-494,-95],[],[],[0.75,0.75]]
         },
         {
            id:'message_bubble_obey',
            type:'image',
            rect:[809,492,250,125],
            opacity:1,
            fill:["rgba(0,0,0,0)",im+"message_bulbble_yield.png"],
            transform:[[-792,-209],[],[],[0.9,0.9]]
         },
         {
            id:'Text_yield_two',
            type:'text',
            rect:[-103,248,180,22],
            opacity:1,
            text:"Always yield to pedestrians.",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',13,"rgba(0,0,0,1)","bold","none","normal"],
            transform:[[167,91]]
         },
         {
            id:'close_button_yield',
            type:'image',
            rect:[824,409,24,24],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"close_updated.png"],
            transform:[[-373,-289],[],[],[0.75,0.75]]
         },
         {
            id:'message_bubble_direction',
            type:'image',
            rect:[763,496,250,125],
            opacity:1,
            fill:["rgba(0,0,0,0)",im+"message_bubble_direction.png"],
            transform:[[-801,-377],[],[],[0.85,0.85]]
         },
         {
            id:'Text_direction',
            type:'text',
            rect:[33,213,163,31],
            opacity:1,
            text:"Bike in the same direction as traffic.",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',12,"rgba(0,0,0,1)","bold","none","normal"],
            transform:[[-2,-14]]
         },
         {
            id:'close_button_direction',
            type:'image',
            rect:[824,409,24,24],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"close_updated.png"],
            transform:[[-808,-276]]
         },
         {
            id:'message_bubble_obey2',
            type:'image',
            rect:[821,490,250,125],
            fill:["rgba(0,0,0,0)",im+"message_bubble_obey2.png"],
            transform:[[-525,-251],[],[],[0.9,0.9]]
         },
         {
            id:'Text_obey',
            type:'text',
            rect:[326,275,162,31],
            opacity:1,
            text:"Obey signs and signals at train crossings.",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',12,"rgba(0,0,0,1)","bold","none","normal"],
            transform:[[-14]]
         },
         {
            id:'close_button_obey',
            type:'image',
            rect:[824,409,24,24],
            cursor:['pointer'],
            opacity:1,
            fill:["rgba(0,0,0,0)",im+"close_updated.png"],
            transform:[[-347,-146],[],[],[0.75,0.75]]
         },
         {
            id:'message_bulbble_carry2',
            type:'image',
            rect:[762,532,250,125],
            fill:["rgba(0,0,0,0)",im+"message_bulbble_carry.png"],
            transform:[[-708,-96]]
         },
         {
            id:'Text_attention',
            type:'text',
            rect:[138,508,168,44],
            text:"Pay attention to vehicles that may enter your path at intersections & driveways.",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',12,"rgba(0,0,0,1)","bold","none","normal"],
            transform:[[-13,-16]]
         },
         {
            id:'close_button_attention',
            type:'image',
            rect:[824,409,24,24],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"close_updated.png"],
            transform:[[-373,-289],[],[],[0.75,0.75]]
         },
         {
            id:'message_bulbble_lights',
            type:'image',
            rect:[846,487,250,125],
            opacity:1,
            fill:["rgba(0,0,0,0)",im+"message_bulbble_carry.png"],
            transform:[[-386,-291],[],[],[0.9,0.9]]
         },
         {
            id:'Text_lights',
            type:'text',
            rect:[539,268,165,31],
            text:"Use lights, reflectors and wear reflective clothing.",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',12,"rgba(0,0,0,1)","bold","none","normal"],
            transform:[[-7]]
         },
         {
            id:'close_button_lights',
            type:'image',
            rect:[824,409,24,24],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"close_updated.png"],
            transform:[[-373,-289],[],[],[0.75,0.75]]
         },
         {
            id:'Symbol_park_red_hazards',
            type:'rect',
            rect:[646,534,0,0]
         },
         {
            id:'bike_avoid_hazards',
            type:'image',
            rect:[813,74,100,100],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"biker_hazards_updated.png"],
            transform:[[-215,-94]]
         },
         {
            id:'message_bubble_hazards2',
            type:'image',
            rect:[807,513,250,125],
            opacity:1,
            fill:["rgba(0,0,0,0)",im+"message_bubble_hazards.png"],
            transform:[[-418,-468]]
         },
         {
            id:'Text_hazards',
            type:'text',
            rect:[487,74,162,30],
            opacity:1,
            text:"Avoid road hazards such as sewer gates, road debris, manholes, etc.",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',12,"rgba(0,0,0,1)","bold","none","normal"],
            transform:[[-23,-15]]
         },
         {
            id:'close_button_hazards',
            type:'image',
            rect:[824,409,24,24],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"close_updated.png"],
            transform:[[-429,-339],[],[],[0.75,0.75]]
         },
         {
            id:'message_bulbble_helmet',
            type:'image',
            rect:[811,473,250,125],
            opacity:1,
            fill:["rgba(0,0,0,0)",im+"message_bulbble_carry.png"],
            transform:[[-665,-443],[],[],[0.9,0.9]]
         },
         {
            id:'Text_helmet',
            type:'text',
            rect:[-159,88,162,36],
            opacity:1,
            text:"Wear a helmet; it's required by law for persons under 18.",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',16,"rgba(0,0,0,1)","bold","none","normal"],
            transform:[[352,-33]]
         },
         {
            id:'close_button_helmet',
            type:'image',
            rect:[824,409,24,24],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"close_updated.png"],
            transform:[[-373,-289],[],[],[0.75,0.75]]
         },
         {
            id:'Symbol_park_red_direction',
            type:'rect',
            rect:[646,534,0,0]
         },
         {
            id:'Symbol_park_red_obey',
            type:'rect',
            rect:[646,534,0,0]
         },
         {
            id:'Symbol_park_red_helmet',
            type:'rect',
            rect:[646,534,0,0]
         },
         {
            id:'Symbol_park_attention',
            type:'rect',
            rect:[272,550,0,0]
         },
         {
            id:'bike_attention',
            type:'image',
            rect:[236,520,100,100],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"biker_updated_attention.png"],
            transform:[[20,-3]]
         },
         {
            id:'bike_direction',
            type:'image',
            rect:[231,244,100,100],
            clip:['rect(0px 80px 99px 0px)'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"biker_updated_direction.png"],
            transform:[[-61,-30]]
         },
         {
            id:'bike_obey',
            type:'image',
            rect:[276,213,100,100],
            clip:['rect(0px 99px 99px 15px)'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"biker_updated_obey.png"],
            transform:[[-31,-36]]
         },
         {
            id:'bike_wear_helmet',
            type:'image',
            rect:[901,436,100,100],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"biker_updated_helmet.png"],
            transform:[[-556,-313]]
         },
         {
            id:'bike_yield',
            type:'image',
            rect:[22,276,100,100],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"biker_updated_yield.png"],
            transform:[[-49,-54]]
         },
         {
            id:'couple_dog',
            type:'image',
            rect:[402,561,38,65],
            fill:["rgba(0,0,0,0)",im+"le_couple_w_chien2.png"],
            transform:[[-45,-60]]
         },
         {
            id:'mother_son_walking',
            type:'image',
            rect:[713,413,35,55],
            fill:["rgba(0,0,0,0)",im+"le_celibataire_mere2.png"],
            transform:[[-40,-66]]
         },
         {
            id:'cars_nw_gray',
            type:'image',
            rect:[815,473,100,69],
            fill:["rgba(0,0,0,0)",im+"cars_nb_bw.png"]
         },
         {
            id:'single_lady',
            type:'image',
            rect:[842,494,35,55],
            fill:["rgba(0,0,0,0)",im+"le_seule_dame2.png"],
            transform:[[-352,-24]]
         },
         {
            id:'Symbol_backlight_carry',
            type:'rect',
            rect:[530,431,0,0]
         },
         {
            id:'Symbol_backlight_attention',
            type:'rect',
            rect:[530,431,0,0]
         },
         {
            id:'Symbol_backlight_lights',
            type:'rect',
            rect:[530,431,0,0]
         },
         {
            id:'signal_screen',
            type:'image',
            rect:[912,430,23,32],
            fill:["rgba(0,0,0,0)",im+"signal_screen.png"],
            transform:[[-864,-156]]
         },
         {
            id:'le_mur',
            type:'image',
            rect:[850,394,161,211],
            clip:['rect(46px 161px 154px 1px)'],
            fill:["rgba(0,0,0,0)",im+"le_mur.png"],
            transform:[[-133,-125]]
         },
         {
            id:'RoundRect',
            type:'rect',
            rect:[20,-8,99,50],
            borderRadius:["10px 10px",10,"10px 10px","10px 10px"],
            opacity:0.6,
            fill:["rgba(0,0,0,1)"],
            stroke:[1,"rgba(0,0,0,1.00)","solid"],
            transform:[[0,-9]]
         },
         {
            id:'refresh_solid',
            type:'image',
            rect:[846,503,70,61],
            cursor:['pointer'],
            opacity:1,
            fill:["rgba(0,0,0,0)",im+"refresh_solid.png"],
            transform:[[-841,-517],[],[],[0.45,0.45]]
         },
         {
            id:'Text',
            type:'text',
            tag:'p',
            rect:[72,6,0,0],
            opacity:0.75342465753425,
            text:"Refresh",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',15,"rgba(0,0,0,1.00)","normal","none","normal"],
            transform:[[-12,-11]]
         },
         {
            id:'TextCopy',
            type:'text',
            tag:'p',
            rect:[72,6,0,0],
            opacity:1,
            text:"Refresh",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',15,"rgba(255,255,255,1.00)","normal","none","normal"],
            transform:[[-11,-12]]
         }],
         symbolInstances: [
         {
            id:'Symbol_park_red_helmet',
            symbolName:'Symbol_park_red'
         },
         {
            id:'Symbol_backlight_attention',
            symbolName:'Symbol_backlight'
         },
         {
            id:'Symbol_lights',
            symbolName:'Symbol_park'
         },
         {
            id:'Symbol_park_orange',
            symbolName:'Symbol_park_orange'
         },
         {
            id:'Symbol_backlight_carry',
            symbolName:'Symbol_backlight'
         },
         {
            id:'Symbol_park_red_direction',
            symbolName:'Symbol_park_red'
         },
         {
            id:'Symbol_park_red_hazards',
            symbolName:'Symbol_park_red'
         },
         {
            id:'Symbol_backlight_lights',
            symbolName:'Symbol_backlight'
         },
         {
            id:'Symbol_carry',
            symbolName:'Symbol_park'
         },
         {
            id:'Symbol_park_attention',
            symbolName:'Symbol_park'
         },
         {
            id:'Symbol_park_red_obey',
            symbolName:'Symbol_park_red'
         }
         ]
      },
   states: {
      "Base State": {
         "${_close_button_direction}": [
            ["style", "display", 'block'],
            ["transform", "translateX", '-808px'],
            ["transform", "translateY", '-276.84px'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '0'],
            ["style", "cursor", 'pointer'],
            ["transform", "scaleY", '0']
         ],
         "${_bike_obey}": [
            ["transform", "translateY", '-333.04px'],
            ["style", "clip", [0,99,99,15], {valueTemplate:'rect(@@0@@px @@1@@px @@2@@px @@3@@px)'} ],
            ["style", "cursor", 'pointer'],
            ["transform", "translateX", '489.6px']
         ],
         "${_close_button_lights}": [
            ["transform", "scaleY", '0'],
            ["transform", "translateX", '-343.83px'],
            ["transform", "translateY", '-206.85px'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '0'],
            ["style", "cursor", 'pointer'],
            ["style", "display", 'block']
         ],
         "${_RoundRect3}": [
            ["style", "border-bottom-right-radius", [0,0], {valueTemplate:'@@0@@px @@1@@px'} ]
         ],
         "${_car_nb_light_blue2}": [
            ["transform", "translateX", '-957px'],
            ["transform", "translateY", '202.79px']
         ],
         "${_signal_screen}": [
            ["transform", "translateX", '-864.32px'],
            ["transform", "translateY", '-156.98px']
         ],
         "${_train_southbound_first}": [
            ["style", "-webkit-transform-origin", [50,50], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "translateY", '-715px'],
            ["transform", "translateX", '-132px']
         ],
         "${_close_button_hazards}": [
            ["transform", "scaleY", '0'],
            ["transform", "translateX", '-429.58px'],
            ["style", "cursor", 'pointer'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-339.84px'],
            ["style", "display", 'block']
         ],
         "${_close_button_yield}": [
            ["transform", "scaleY", '0'],
            ["transform", "translateX", '-616.07px'],
            ["transform", "translateY", '-92.72px'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '0'],
            ["style", "cursor", 'pointer'],
            ["style", "display", 'block']
         ],
         "${_TextCopy}": [
            ["transform", "translateX", '-11.99px'],
            ["style", "font-weight", 'normal'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-12px'],
            ["style", "font-size", '15px']
         ],
         "${_Symbol_backlight_lights}": [
            ["transform", "translateY", '-109.84px'],
            ["style", "opacity", '0'],
            ["style", "clip", [3,15,15,4], {valueTemplate:'rect(@@0@@px @@1@@px @@2@@px @@3@@px)'} ],
            ["transform", "translateX", '161.07px']
         ],
         "${_Light_post_green2}": [
            ["transform", "translateX", '-302.4px'],
            ["transform", "translateY", '-241px']
         ],
         "${_close_button_obey}": [
            ["transform", "scaleY", '0'],
            ["transform", "translateX", '-347px'],
            ["style", "cursor", 'pointer'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-146.84px'],
            ["style", "display", 'block']
         ],
         "${_Symbol_park_orange}": [
            ["transform", "scaleX", '-1.06'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-238.84px'],
            ["transform", "translateX", '-866.98px']
         ],
         "${_message_bubble_obey2}": [
            ["style", "-webkit-transform-origin", [0,0], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [0,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [0,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [0,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [0,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "translateX", '-525.79px'],
            ["transform", "scaleY", '0'],
            ["style", "display", 'block'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-251.96px'],
            ["transform", "scaleX", '0']
         ],
         "${_car_sb_gray2}": [
            ["transform", "translateX", '492.59px'],
            ["transform", "translateY", '-864px']
         ],
         "${_close_button_helmet}": [
            ["style", "display", 'block'],
            ["transform", "scaleY", '0'],
            ["style", "cursor", 'pointer'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-375.1px'],
            ["transform", "translateX", '-658.7px']
         ],
         "${_car_nb_orange2}": [
            ["transform", "translateX", '-1264.8px'],
            ["transform", "translateY", '340.18px']
         ],
         "${_train_northbound_first}": [
            ["transform", "translateX", '-1272px'],
            ["transform", "translateY", '22.99px']
         ],
         "${_bike_carry}": [
            ["style", "cursor", 'pointer'],
            ["transform", "translateY", '253.87px'],
            ["transform", "translateX", '-607.56px']
         ],
         "${_Text_direction}": [
            ["style", "width", '148px'],
            ["transform", "translateX", '6.98px'],
            ["style", "display", 'block'],
            ["style", "height", '50px'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-58.19px'],
            ["style", "font-size", '16px']
         ],
         "${_Text}": [
            ["transform", "translateX", '-12.99px'],
            ["style", "font-weight", 'normal'],
            ["color", "color", 'rgba(0,0,0,1.00)'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-11px'],
            ["style", "font-size", '15px']
         ],
         "${_Stage}": [
            ["style", "height", '600px'],
            ["style", "overflow", 'hidden'],
            ["color", "background-color", 'rgba(0,0,0,0.00)'],
            ["style", "width", '750px']
         ],
         "${_le_mur}": [
            ["transform", "translateX", '-133.01px'],
            ["transform", "translateY", '-125.15px'],
            ["style", "clip", [46,161,154,1], {valueTemplate:'rect(@@0@@px @@1@@px @@2@@px @@3@@px)'} ]
         ],
         "${_couple_dog}": [
            ["transform", "translateX", '-45px'],
            ["transform", "translateY", '-60px']
         ],
         "${_close_button_attention}": [
            ["style", "display", 'block'],
            ["transform", "translateX", '-775.12px'],
            ["style", "cursor", 'pointer'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '23.92px'],
            ["transform", "scaleY", '0']
         ],
         "body": [
            ["color", "background-color", 'rgba(0,0,0,0)']
         ],
         "${_mother_son_walking}": [
            ["transform", "translateY", '-66px'],
            ["transform", "translateX", '-40px']
         ],
         "${_single_lady}": [
            ["transform", "translateX", '-352.43px'],
            ["transform", "translateY", '-24.05px']
         ],
         "${_car_sb_green2}": [
            ["transform", "translateX", '269.38px'],
            ["transform", "translateY", '-742px']
         ],
         "${_bike_avoid_hazards}": [
            ["transform", "translateX", '210.89px'],
            ["transform", "translateY", '-374.99px'],
            ["style", "cursor", 'pointer']
         ],
         "${_Text_attention}": [
            ["style", "-webkit-transform-origin", [50,50], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "font-size", '16px'],
            ["transform", "translateX", '-67.35px'],
            ["style", "display", 'block'],
            ["style", "height", '58px'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-58.61px'],
            ["style", "width", '210px']
         ],
         "${_Symbol_lights}": [
            ["style", "opacity", '0'],
            ["transform", "translateX", '408.77px'],
            ["transform", "translateY", '-239.91px']
         ],
         "${_train_northbound_second}": [
            ["transform", "translateX", '-1321px'],
            ["transform", "translateY", '53.59px']
         ],
         "${_message_bubble_obey}": [
            ["style", "-webkit-transform-origin", [0,0], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [0,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [0,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [0,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [0,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "display", 'block'],
            ["transform", "scaleY", '0'],
            ["transform", "translateY", '-216.89px'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '0'],
            ["style", "clip", [16,225,125,17], {valueTemplate:'rect(@@0@@px @@1@@px @@2@@px @@3@@px)'} ],
            ["transform", "translateX", '-785.87px']
         ],
         "${_Text_helmet}": [
            ["transform", "translateX", '352.21px'],
            ["style", "width", '162px'],
            ["style", "height", '52px'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-33.09px'],
            ["style", "font-size", '16px']
         ],
         "${_bike_direction}": [
            ["transform", "translateY", '-327.24px'],
            ["style", "clip", [0,80,99,0], {valueTemplate:'rect(@@0@@px @@1@@px @@2@@px @@3@@px)'} ],
            ["style", "cursor", 'pointer'],
            ["transform", "translateX", '459.59px']
         ],
         "${_Light_post_back2}": [
            ["transform", "translateX", '-446.6px'],
            ["transform", "translateY", '-114.8px']
         ],
         "${_bike_attention}": [
            ["transform", "translateY", '291.81px'],
            ["style", "cursor", 'pointer'],
            ["transform", "translateX", '-495.96px']
         ],
         "${_Symbol_park_red_direction}": [
            ["style", "opacity", '0'],
            ["transform", "translateY", '-283.56px'],
            ["transform", "translateX", '-460.83px']
         ],
         "${_RoundRect}": [
            ["style", "border-top-left-radius", [10,10], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["transform", "translateX", '0.5px'],
            ["style", "border-bottom-right-radius", [10,10], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "opacity", '0'],
            ["style", "border-width", '1px'],
            ["style", "width", '99px'],
            ["style", "border-bottom-left-radius", [10,10], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "height", '50px'],
            ["color", "border-color", 'rgba(0,0,0,1.00)'],
            ["transform", "translateY", '-9.5px'],
            ["style", "border-style", 'solid']
         ],
         "${_Symbol_park_red_hazards}": [
            ["style", "opacity", '0'],
            ["transform", "translateY", '-516.56px'],
            ["transform", "translateX", '-31.83px']
         ],
         "${_Symbol_backlight_attention}": [
            ["transform", "translateY", '129.52px'],
            ["style", "opacity", '0'],
            ["style", "clip", [3,15,15,4], {valueTemplate:'rect(@@0@@px @@1@@px @@2@@px @@3@@px)'} ],
            ["transform", "translateX", '-246.18px']
         ],
         "${_bike_lights2}": [
            ["transform", "translateX", '-671.92px'],
            ["transform", "translateY", '205.2px'],
            ["style", "cursor", 'pointer']
         ],
         "${_bike_yield}": [
            ["style", "cursor", 'pointer'],
            ["transform", "translateY", '-54.4px'],
            ["transform", "translateX", '-49.4px'],
            ["transform", "rotateZ", '-0deg']
         ],
         "${_refresh_solid}": [
            ["transform", "translateX", '-841.52px'],
            ["style", "cursor", 'pointer'],
            ["transform", "scaleX", '0.45'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-517.15px'],
            ["transform", "scaleY", '0.45']
         ],
         "${_cars_nw_gray}": [
            ["transform", "translateX", '-193.17px'],
            ["transform", "translateY", '-16.78px']
         ],
         "${_Text_yield_two}": [
            ["style", "font-size", '16px'],
            ["transform", "translateX", '185.51px'],
            ["style", "display", 'block'],
            ["style", "height", '36px'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '91.16px'],
            ["style", "width", '180px']
         ],
         "${_Symbol_park_red_helmet}": [
            ["style", "opacity", '0'],
            ["transform", "translateY", '-373.56px'],
            ["transform", "translateX", '-285.83px']
         ],
         "${_Text_hazards}": [
            ["style", "width", '197px'],
            ["transform", "translateX", '-69.15px'],
            ["style", "display", 'block'],
            ["style", "height", '64px'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '14.36px'],
            ["style", "font-size", '16px']
         ],
         "${_Symbol_park_attention}": [
            ["style", "opacity", '0']
         ],
         "${_car_sb_gray2Copy}": [
            ["transform", "translateX", '-172px'],
            ["transform", "translateY", '-471px']
         ],
         "${_Text_carry}": [
            ["style", "font-size", '16px'],
            ["style", "height", '44px'],
            ["transform", "translateX", '479.32px'],
            ["style", "opacity", '0'],
            ["style", "display", 'block'],
            ["style", "font-weight", 'bold'],
            ["transform", "translateY", '-5.45px'],
            ["style", "width", '190px']
         ],
         "${_bike_wear_helmet}": [
            ["transform", "translateX", '-35.52px'],
            ["transform", "translateY", '-626.16px'],
            ["style", "cursor", 'pointer']
         ],
         "${_message_bubble_direction}": [
            ["style", "-webkit-transform-origin", [100,100], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "translateX", '-801.09px'],
            ["transform", "scaleY", '0'],
            ["style", "display", 'block'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-377.92px'],
            ["transform", "scaleX", '0']
         ],
         "${_bike_background}": [
            ["transform", "translateX", '0px'],
            ["transform", "translateY", '-1px']
         ],
         "${_message_bulbble_carry}": [
            ["style", "-webkit-transform-origin", [100,100], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "translateX", '-527.11px'],
            ["transform", "scaleY", '0'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-177.73px'],
            ["style", "display", 'block']
         ],
         "${_car_nb_gray2}": [
            ["transform", "translateX", '-910px'],
            ["transform", "translateY", '106.99px']
         ],
         "${_train_southbound_second}": [
            ["style", "-webkit-transform-origin", [50,50], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [50,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "translateX", '-124.99px'],
            ["transform", "translateY", '-711.32px']
         ],
         "${_car_sb_light_blue2}": [
            ["transform", "translateX", '40.99px'],
            ["transform", "translateY", '-518.4px']
         ],
         "${_Text_obey}": [
            ["style", "width", '155px'],
            ["transform", "translateX", '10.99px'],
            ["style", "display", 'block'],
            ["style", "height", '62px'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '0.11px'],
            ["style", "font-size", '16px']
         ],
         "${_close_button_carry}": [
            ["style", "display", 'block'],
            ["transform", "translateX", '-517.12px'],
            ["transform", "translateY", '-104.07px'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '0'],
            ["style", "cursor", 'pointer'],
            ["transform", "scaleY", '0']
         ],
         "${_bike_backgroundCopy}": [
            ["transform", "translateX", '0px'],
            ["transform", "translateY", '-1px']
         ],
         "${_message_bulbble_helmet}": [
            ["style", "-webkit-transform-origin", [100,100], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "translateX", '-665.19px'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-443.78px'],
            ["transform", "scaleY", '0']
         ],
         "${_Symbol_backlight_carry}": [
            ["transform", "translateX", '1px'],
            ["style", "opacity", '0'],
            ["style", "clip", [3,15,15,4], {valueTemplate:'rect(@@0@@px @@1@@px @@2@@px @@3@@px)'} ],
            ["transform", "translateY", '1px']
         ],
         "${_Symbol_carry}": [
            ["style", "opacity", '0'],
            ["transform", "translateX", '248.77px'],
            ["transform", "translateY", '-128.91px']
         ],
         "${_message_bulbble_lights}": [
            ["style", "-webkit-transform-origin", [100,100], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "translateX", '-386.03px'],
            ["transform", "scaleY", '0'],
            ["style", "display", 'block'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-291.71px'],
            ["transform", "scaleX", '0']
         ],
         "${_Text_lights}": [
            ["style", "width", '165px'],
            ["transform", "translateX", '-35.87px'],
            ["style", "display", 'block'],
            ["style", "height", '51px'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-47.38px'],
            ["style", "font-size", '16px']
         ],
         "${_message_bulbble_carry2}": [
            ["style", "-webkit-transform-origin", [100,100], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [100,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "scaleY", '0'],
            ["transform", "translateX", '-708.42px'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-96.5px'],
            ["style", "display", 'block']
         ],
         "${_Symbol_park_red_obey}": [
            ["style", "opacity", '0'],
            ["transform", "translateY", '-317.56px'],
            ["transform", "translateX", '-386.83px']
         ],
         "${_message_bubble_hazards2}": [
            ["style", "-webkit-transform-origin", [100,0], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [100,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [100,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [100,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [100,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "translateX", '-418.32px'],
            ["transform", "scaleY", '0'],
            ["style", "display", 'block'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-468.15px'],
            ["transform", "scaleX", '0']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 21940,
         autoPlay: true,
         labels: {
            "motion": 100,
            "motionstart": 1000,
            "lightup": 6750,
            "begining": 7260,
            "carry": 8250,
            "yield": 10005,
            "direction": 11750,
            "obey": 13500,
            "attention": 15250,
            "lights": 17000,
            "hazards": 18750,
            "helmet": 20500
         },
         timeline: [
            { id: "eid3231", tween: [ "transform", "${_message_bulbble_helmet}", "scaleX", '0.9', { fromValue: '0'}], position: 20499, duration: 1001, easing: "easeOutBack" },
            { id: "eid3788", tween: [ "transform", "${_message_bubble_obey}", "translateX", '-785.87px', { fromValue: '-785.87px'}], position: 10005, duration: 0, easing: "easeOutBack" },
            { id: "eid2404", tween: [ "transform", "${_bike_attention}", "translateX", '20.04px', { fromValue: '-495.96px'}], position: 3500, duration: 3265 },
            { id: "eid3654", tween: [ "style", "${_Symbol_park_red_obey}", "opacity", '1', { fromValue: '0'}], position: 6745, duration: 255 },
            { id: "eid3751", tween: [ "transform", "${_close_button_attention}", "scaleX", '0.9', { fromValue: '0'}], position: 16190, duration: 250 },
            { id: "eid2947", tween: [ "style", "${_message_bulbble_carry}", "opacity", '1', { fromValue: '0'}], position: 8240, duration: 1010, easing: "easeOutBack" },
            { id: "eid3139", tween: [ "transform", "${_message_bulbble_carry2}", "scaleY", '1', { fromValue: '0'}], position: 15250, duration: 1000, easing: "easeOutBack" },
            { id: "eid2172", tween: [ "style", "${_close_button_carry}", "display", 'none', { fromValue: 'block'}], position: 9793, duration: 0, easing: "easeInOutBack" },
            { id: "eid3823", tween: [ "transform", "${_train_southbound_second}", "translateX", '-581.66px', { fromValue: '-124.99px'}], position: 4921, duration: 1844, easing: "easeOutQuad" },
            { id: "eid3205", tween: [ "style", "${_Text_lights}", "opacity", '1', { fromValue: '0'}], position: 17935, duration: 560 },
            { id: "eid3174", tween: [ "transform", "${_message_bulbble_lights}", "scaleX", '0.9', { fromValue: '0'}], position: 17000, duration: 1000, easing: "easeOutBack" },
            { id: "eid3176", tween: [ "transform", "${_message_bulbble_lights}", "scaleY", '0.9', { fromValue: '0'}], position: 17000, duration: 1000, easing: "easeOutBack" },
            { id: "eid354", tween: [ "transform", "${_train_northbound_first}", "translateY", '-627px', { fromValue: '22.99px'}], position: 1000, duration: 3921, easing: "easeOutQuad" },
            { id: "eid3411", tween: [ "style", "${_Text_direction}", "width", '148px', { fromValue: '148px'}], position: 12690, duration: 0, easing: "easeOutBack" },
            { id: "eid3656", tween: [ "style", "${_Symbol_lights}", "opacity", '1', { fromValue: '0'}], position: 6745, duration: 255 },
            { id: "eid2148", tween: [ "style", "${_close_button_hazards}", "display", 'none', { fromValue: 'block'}], position: 20286, duration: 0 },
            { id: "eid2736", tween: [ "style", "${_Symbol_backlight_lights}", "clip", [3,15,15,4], { valueTemplate: 'rect(@@0@@px @@1@@px @@2@@px @@3@@px)', fromValue: [3,15,15,4]}], position: 8240, duration: 0 },
            { id: "eid2653", tween: [ "transform", "${_Symbol_backlight_attention}", "translateY", '129.52px', { fromValue: '129.52px'}], position: 6740, duration: 0 },
            { id: "eid3392", tween: [ "transform", "${_bike_avoid_hazards}", "translateY", '-94.01px', { fromValue: '-374.99px'}], position: 3500, duration: 3265 },
            { id: "eid2150", tween: [ "style", "${_close_button_lights}", "display", 'none', { fromValue: 'block'}], position: 18536, duration: 0 },
            { id: "eid3023", tween: [ "transform", "${_Text_yield_two}", "translateX", '185.51px', { fromValue: '185.51px'}], position: 11000, duration: 0, easing: "easeOutBack" },
            { id: "eid3390", tween: [ "transform", "${_bike_avoid_hazards}", "translateX", '-215.11px', { fromValue: '210.89px'}], position: 3500, duration: 3265 },
            { id: "eid3424", tween: [ "transform", "${_message_bubble_direction}", "scaleY", '0.85', { fromValue: '0'}], position: 11750, duration: 1000, easing: "easeOutBack" },
            { id: "eid2416", tween: [ "transform", "${_bike_carry}", "translateX", '-35.56px', { fromValue: '-607.56px'}], position: 3500, duration: 3265 },
            { id: "eid819", tween: [ "transform", "${_car_nb_orange2}", "translateY", '-17px', { fromValue: '340.18px'}], position: 1000, duration: 5740, easing: "swing" },
            { id: "eid3335", tween: [ "style", "${_Text_hazards}", "opacity", '1', { fromValue: '0'}], position: 19690, duration: 510 },
            { id: "eid3793", tween: [ "style", "${_message_bubble_obey}", "clip", [16,225,125,17], { valueTemplate: 'rect(@@0@@px @@1@@px @@2@@px @@3@@px)', fromValue: [16,225,125,17]}], position: 10005, duration: 0, easing: "easeOutBack" },
            { id: "eid3799", tween: [ "transform", "${_message_bubble_obey}", "scaleY", '1', { fromValue: '0'}], position: 10005, duration: 995, easing: "easeOutBack" },
            { id: "eid2308", tween: [ "transform", "${_bike_direction}", "translateY", '-30.6px', { fromValue: '-327.24px'}], position: 3500, duration: 3265, easing: "easeOutQuad" },
            { id: "eid3229", tween: [ "style", "${_message_bulbble_helmet}", "opacity", '1', { fromValue: '0'}], position: 20499, duration: 1001, easing: "easeOutBack" },
            { id: "eid3346", tween: [ "transform", "${_close_button_hazards}", "scaleY", '0.9', { fromValue: '0'}], position: 19690, duration: 243 },
            { id: "eid3768", tween: [ "style", "${_close_button_helmet}", "opacity", '1', { fromValue: '0'}], position: 21374, duration: 251 },
            { id: "eid809", tween: [ "transform", "${_car_sb_green2}", "translateX", '-482.61px', { fromValue: '269.38px'}], position: 1012, duration: 5727, easing: "swing" },
            { id: "eid3370", tween: [ "transform", "${_close_button_lights}", "scaleX", '0.9', { fromValue: '0'}], position: 17935, duration: 253 },
            { id: "eid3158", tween: [ "transform", "${_Text_attention}", "translateY", '-58.61px', { fromValue: '-58.61px'}], position: 16190, duration: 0, easing: "easeOutBack" },
            { id: "eid3160", tween: [ "style", "${_Text_attention}", "width", '210px', { fromValue: '210px'}], position: 16190, duration: 0, easing: "easeOutBack" },
            { id: "eid3327", tween: [ "transform", "${_message_bubble_hazards2}", "scaleX", '1', { fromValue: '0'}], position: 18750, duration: 1000, easing: "easeOutBack" },
            { id: "eid3477", tween: [ "transform", "${_close_button_obey}", "scaleX", '0.9', { fromValue: '0'}], position: 14400, duration: 247 },
            { id: "eid797", tween: [ "transform", "${_car_sb_light_blue2}", "translateX", '-711px', { fromValue: '40.99px'}], position: 1012, duration: 5727, easing: "swing" },
            { id: "eid3233", tween: [ "transform", "${_message_bulbble_helmet}", "scaleY", '0.9', { fromValue: '0'}], position: 20499, duration: 1001, easing: "easeOutBack" },
            { id: "eid3706", tween: [ "style", "${_Text}", "opacity", '0.7534246444702148', { fromValue: '0'}], position: 6739, duration: 241, easing: "easeOutBack" },
            { id: "eid3344", tween: [ "transform", "${_close_button_hazards}", "scaleX", '0.9', { fromValue: '0'}], position: 19690, duration: 243 },
            { id: "eid3159", tween: [ "transform", "${_Text_attention}", "translateX", '-67.35px', { fromValue: '-67.35px'}], position: 16190, duration: 0, easing: "easeOutBack" },
            { id: "eid3465", tween: [ "transform", "${_message_bubble_obey2}", "scaleY", '0.9', { fromValue: '0'}], position: 13500, duration: 1000, easing: "easeOutBack" },
            { id: "eid2654", tween: [ "transform", "${_Symbol_backlight_attention}", "translateX", '-246.18px', { fromValue: '-246.18px'}], position: 6740, duration: 0 },
            { id: "eid3420", tween: [ "style", "${_message_bubble_direction}", "opacity", '1', { fromValue: '0'}], position: 11750, duration: 1000, easing: "easeOutBack" },
            { id: "eid2170", tween: [ "style", "${_Text_yield_two}", "display", 'none', { fromValue: 'block'}], position: 11538, duration: 0 },
            { id: "eid3662", tween: [ "style", "${_Symbol_park_red_hazards}", "opacity", '1', { fromValue: '0'}], position: 6745, duration: 255 },
            { id: "eid3467", tween: [ "style", "${_Text_obey}", "opacity", '1', { fromValue: '0'}], position: 14400, duration: 600, easing: "easeOutBack" },
            { id: "eid3269", tween: [ "transform", "${_bike_wear_helmet}", "translateX", '-556.52px', { fromValue: '-35.52px'}], position: 3500, duration: 3265, easing: "easeOutQuad" },
            { id: "eid3461", tween: [ "style", "${_message_bubble_obey2}", "opacity", '1', { fromValue: '0'}], position: 13500, duration: 1000, easing: "easeOutBack" },
            { id: "eid3418", tween: [ "style", "${_Text_direction}", "opacity", '1', { fromValue: '0'}], position: 12690, duration: 560, easing: "easeOutBack" },
            { id: "eid2166", tween: [ "style", "${_close_button_direction}", "display", 'none', { fromValue: 'block'}], position: 13293, duration: 0 },
            { id: "eid815", tween: [ "transform", "${_car_nb_gray2}", "translateY", '-250.19px', { fromValue: '106.99px'}], position: 1000, duration: 5740, easing: "swing" },
            { id: "eid3178", tween: [ "style", "${_message_bulbble_lights}", "opacity", '1', { fromValue: '0'}], position: 17000, duration: 1000, easing: "easeOutBack" },
            { id: "eid3433", tween: [ "transform", "${_close_button_direction}", "scaleX", '0.9', { fromValue: '0'}], position: 12690, duration: 252 },
            { id: "eid3480", tween: [ "style", "${_Text_obey}", "display", 'none', { fromValue: 'block'}], position: 15038, duration: 0, easing: "easeOutBack" },
            { id: "eid799", tween: [ "transform", "${_car_sb_light_blue2}", "translateY", '-94.4px', { fromValue: '-518.4px'}], position: 1012, duration: 5727, easing: "swing" },
            { id: "eid3481", tween: [ "style", "${_message_bubble_obey2}", "display", 'none', { fromValue: 'block'}], position: 15038, duration: 0, easing: "easeOutBack" },
            { id: "eid823", tween: [ "transform", "${_car_nb_light_blue2}", "translateY", '-154.39px', { fromValue: '202.79px'}], position: 1000, duration: 5740, easing: "swing" },
            { id: "eid3789", tween: [ "transform", "${_message_bubble_obey}", "translateY", '-216.89px', { fromValue: '-216.89px'}], position: 10005, duration: 0, easing: "easeOutBack" },
            { id: "eid3795", tween: [ "style", "${_message_bubble_obey}", "opacity", '1', { fromValue: '0'}], position: 10005, duration: 995, easing: "easeOutBack" },
            { id: "eid3422", tween: [ "transform", "${_message_bubble_direction}", "scaleX", '0.85', { fromValue: '0'}], position: 11750, duration: 1000, easing: "easeOutBack" },
            { id: "eid3666", tween: [ "style", "${_Symbol_park_red_direction}", "opacity", '1', { fromValue: '0'}], position: 6745, duration: 255 },
            { id: "eid336", tween: [ "transform", "${_train_southbound_first}", "translateY", '-27px', { fromValue: '-715px'}], position: 1000, duration: 3921, easing: "easeOutQuad" },
            { id: "eid3329", tween: [ "transform", "${_message_bubble_hazards2}", "scaleY", '1', { fromValue: '0'}], position: 18750, duration: 1000, easing: "easeOutBack" },
            { id: "eid3413", tween: [ "style", "${_Text_direction}", "height", '50px', { fromValue: '50px'}], position: 12690, duration: 0, easing: "easeOutBack" },
            { id: "eid2962", tween: [ "transform", "${_close_button_carry}", "translateY", '-104.07px', { fromValue: '-104.07px'}], position: 9165, duration: 0 },
            { id: "eid2167", tween: [ "style", "${_Text_direction}", "display", 'none', { fromValue: 'block'}], position: 13293, duration: 0 },
            { id: "eid3755", tween: [ "style", "${_close_button_attention}", "opacity", '1', { fromValue: '0'}], position: 16190, duration: 250 },
            { id: "eid3825", tween: [ "transform", "${_train_southbound_second}", "translateY", '-454.66px', { fromValue: '-711.32px'}], position: 4921, duration: 1844, easing: "easeOutQuad" },
            { id: "eid3407", tween: [ "style", "${_Text_direction}", "font-size", '16px', { fromValue: '16px'}], position: 12690, duration: 0, easing: "easeOutBack" },
            { id: "eid3401", tween: [ "style", "${_message_bubble_hazards2}", "display", 'none', { fromValue: 'block'}], position: 20286, duration: 0, easing: "easeOutBack" },
            { id: "eid3009", tween: [ "style", "${_Text_carry}", "opacity", '1', { fromValue: '0'}], position: 9165, duration: 585, easing: "easeOutBack" },
            { id: "eid2647", tween: [ "transform", "${_Symbol_backlight_carry}", "translateY", '1px', { fromValue: '1px'}], position: 6740, duration: 0 },
            { id: "eid2153", tween: [ "style", "${_close_button_attention}", "display", 'none', { fromValue: 'block'}], position: 16788, duration: 0 },
            { id: "eid3475", tween: [ "style", "${_close_button_obey}", "opacity", '1', { fromValue: '0'}], position: 14400, duration: 247 },
            { id: "eid2147", tween: [ "style", "${_Text_hazards}", "display", 'none', { fromValue: 'block'}], position: 20286, duration: 0 },
            { id: "eid803", tween: [ "transform", "${_car_sb_gray2Copy}", "translateY", '-47px', { fromValue: '-471px'}], position: 1012, duration: 5727, easing: "swing" },
            { id: "eid2943", tween: [ "transform", "${_message_bulbble_carry}", "scaleX", '0.95', { fromValue: '0'}], position: 8240, duration: 1010, easing: "easeOutBack" },
            { id: "eid2625", tween: [ "style", "${_Symbol_backlight_attention}", "opacity", '1', { fromValue: '0'}], position: 6740, duration: 240 },
            { id: "eid3712", tween: [ "style", "${_TextCopy}", "opacity", '1', { fromValue: '0'}], position: 6739, duration: 241, easing: "easeOutBack" },
            { id: "eid2961", tween: [ "transform", "${_close_button_carry}", "translateX", '-517.12px', { fromValue: '-517.12px'}], position: 9165, duration: 0 },
            { id: "eid334", tween: [ "transform", "${_train_southbound_first}", "translateX", '-1321px', { fromValue: '-132px'}], position: 1000, duration: 3921, easing: "easeOutQuad" },
            { id: "eid2968", tween: [ "transform", "${_close_button_carry}", "scaleY", '0.9', { fromValue: '0'}], position: 9165, duration: 244 },
            { id: "eid3325", tween: [ "style", "${_message_bubble_hazards2}", "opacity", '1', { fromValue: '0'}], position: 18750, duration: 1000, easing: "easeOutBack" },
            { id: "eid3162", tween: [ "style", "${_Text_attention}", "opacity", '1', { fromValue: '0'}], position: 16190, duration: 560, easing: "easeOutBack" },
            { id: "eid3438", tween: [ "style", "${_message_bubble_direction}", "display", 'none', { fromValue: 'block'}], position: 13293, duration: 0, easing: "easeOutBack" },
            { id: "eid2406", tween: [ "transform", "${_bike_attention}", "translateY", '-3.39px', { fromValue: '291.81px'}], position: 3500, duration: 3265 },
            { id: "eid3817", tween: [ "style", "${_close_button_yield}", "opacity", '1', { fromValue: '0'}], position: 10940, duration: 244, easing: "easeOutBack" },
            { id: "eid3819", tween: [ "transform", "${_close_button_yield}", "scaleX", '0.9', { fromValue: '0'}], position: 10940, duration: 244, easing: "easeOutBack" },
            { id: "eid3708", tween: [ "style", "${_refresh_solid}", "opacity", '1', { fromValue: '0'}], position: 6739, duration: 241, easing: "easeOutBack" },
            { id: "eid2169", tween: [ "style", "${_close_button_yield}", "display", 'none', { fromValue: 'block'}], position: 11538, duration: 0 },
            { id: "eid821", tween: [ "transform", "${_car_nb_light_blue2}", "translateX", '-338.2px', { fromValue: '-957px'}], position: 1000, duration: 5740, easing: "swing" },
            { id: "eid2740", tween: [ "style", "${_Symbol_backlight_carry}", "clip", [3,15,15,4], { valueTemplate: 'rect(@@0@@px @@1@@px @@2@@px @@3@@px)', fromValue: [3,15,15,4]}], position: 8240, duration: 0 },
            { id: "eid390", tween: [ "style", "${_RoundRect3}", "border-bottom-right-radius", [0,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [0,0]}], position: 0, duration: 0 },
            { id: "eid3664", tween: [ "style", "${_Symbol_park_attention}", "opacity", '1', { fromValue: '0'}], position: 6745, duration: 255 },
            { id: "eid3018", tween: [ "style", "${_Text_yield_two}", "font-size", '16px', { fromValue: '16px'}], position: 11000, duration: 0, easing: "easeOutBack" },
            { id: "eid801", tween: [ "transform", "${_car_sb_gray2Copy}", "translateX", '-924px', { fromValue: '-172px'}], position: 1012, duration: 5727, easing: "swing" },
            { id: "eid2840", tween: [ "style", "${_close_button_helmet}", "display", 'none', { fromValue: 'block'}], position: 21940, duration: 0 },
            { id: "eid3660", tween: [ "style", "${_Symbol_park_orange}", "opacity", '1', { fromValue: '0'}], position: 6745, duration: 255 },
            { id: "eid3753", tween: [ "transform", "${_close_button_attention}", "scaleY", '0.9', { fromValue: '0'}], position: 16190, duration: 250 },
            { id: "eid2157", tween: [ "style", "${_close_button_obey}", "display", 'none', { fromValue: 'block'}], position: 15038, duration: 0, easing: "easeOutBack" },
            { id: "eid811", tween: [ "transform", "${_car_sb_green2}", "translateY", '-318px', { fromValue: '-742px'}], position: 1012, duration: 5727, easing: "swing" },
            { id: "eid3658", tween: [ "style", "${_Symbol_carry}", "opacity", '1', { fromValue: '0'}], position: 6745, duration: 255 },
            { id: "eid2648", tween: [ "transform", "${_Symbol_backlight_carry}", "translateX", '1px', { fromValue: '1px'}], position: 6740, duration: 0 },
            { id: "eid3710", tween: [ "style", "${_RoundRect}", "opacity", '0.6000000238418579', { fromValue: '0'}], position: 6739, duration: 241, easing: "easeOutBack" },
            { id: "eid3372", tween: [ "transform", "${_close_button_lights}", "scaleY", '0.9', { fromValue: '0'}], position: 17935, duration: 253 },
            { id: "eid3007", tween: [ "transform", "${_Text_carry}", "translateY", '-5.45px', { fromValue: '-5.45px'}], position: 9165, duration: 0, easing: "easeOutBack" },
            { id: "eid3374", tween: [ "style", "${_close_button_lights}", "opacity", '1', { fromValue: '0'}], position: 17935, duration: 253 },
            { id: "eid813", tween: [ "transform", "${_car_nb_gray2}", "translateX", '-291.2px', { fromValue: '-910px'}], position: 1000, duration: 5740, easing: "swing" },
            { id: "eid3207", tween: [ "style", "${_message_bulbble_lights}", "display", 'none', { fromValue: 'block'}], position: 18536, duration: 0, easing: "easeOutBack" },
            { id: "eid3416", tween: [ "transform", "${_Text_direction}", "translateX", '6.98px', { fromValue: '6.98px'}], position: 12690, duration: 0, easing: "easeOutBack" },
            { id: "eid3150", tween: [ "style", "${_message_bulbble_carry2}", "display", 'none', { fromValue: 'block'}], position: 16788, duration: 0, easing: "easeOutBack" },
            { id: "eid807", tween: [ "transform", "${_car_sb_gray2}", "translateY", '-440px', { fromValue: '-864px'}], position: 1012, duration: 5727, easing: "swing" },
            { id: "eid2304", tween: [ "transform", "${_bike_obey}", "translateY", '-36.4px', { fromValue: '-333.04px'}], position: 3500, duration: 3265, easing: "easeOutQuad" },
            { id: "eid2408", tween: [ "transform", "${_bike_lights2}", "translateX", '-155.92px', { fromValue: '-671.92px'}], position: 3500, duration: 3265 },
            { id: "eid2759", tween: [ "style", "${_Symbol_backlight_attention}", "clip", [3,15,15,4], { valueTemplate: 'rect(@@0@@px @@1@@px @@2@@px @@3@@px)', fromValue: [3,15,15,4]}], position: 6740, duration: 0 },
            { id: "eid3437", tween: [ "style", "${_close_button_direction}", "opacity", '1', { fromValue: '0'}], position: 12690, duration: 252 },
            { id: "eid3797", tween: [ "transform", "${_message_bubble_obey}", "scaleX", '1', { fromValue: '0'}], position: 10005, duration: 995, easing: "easeOutBack" },
            { id: "eid3435", tween: [ "transform", "${_close_button_direction}", "scaleY", '0.9', { fromValue: '0'}], position: 12690, duration: 252 },
            { id: "eid817", tween: [ "transform", "${_car_nb_orange2}", "translateX", '-646px', { fromValue: '-1264.8px'}], position: 1000, duration: 5740, easing: "swing" },
            { id: "eid2966", tween: [ "transform", "${_close_button_carry}", "scaleX", '0.9', { fromValue: '0'}], position: 9165, duration: 244 },
            { id: "eid350", tween: [ "transform", "${_train_northbound_second}", "translateY", '-118.4px', { fromValue: '53.59px'}], position: 4921, duration: 1828, easing: "easeOutQuad" },
            { id: "eid2641", tween: [ "style", "${_Symbol_backlight_lights}", "opacity", '1', { fromValue: '0'}], position: 6740, duration: 240 },
            { id: "eid2410", tween: [ "transform", "${_bike_lights2}", "translateY", '-90px', { fromValue: '205.2px'}], position: 3500, duration: 3265 },
            { id: "eid3135", tween: [ "style", "${_message_bulbble_carry2}", "opacity", '1', { fromValue: '0'}], position: 15250, duration: 1000, easing: "easeOutBack" },
            { id: "eid3043", tween: [ "style", "${_message_bubble_obey}", "display", 'none', { fromValue: 'block'}], position: 11538, duration: 0, easing: "easeOutBack" },
            { id: "eid2173", tween: [ "style", "${_Text_carry}", "display", 'none', { fromValue: 'block'}], position: 9793, duration: 0, easing: "easeInOutBack" },
            { id: "eid352", tween: [ "transform", "${_train_northbound_first}", "translateX", '-132px', { fromValue: '-1272px'}], position: 1000, duration: 3921, easing: "easeOutQuad" },
            { id: "eid2418", tween: [ "transform", "${_bike_carry}", "translateY", '-34.92px', { fromValue: '253.87px'}], position: 3500, duration: 3265 },
            { id: "eid3821", tween: [ "transform", "${_close_button_yield}", "scaleY", '0.9', { fromValue: '0'}], position: 10940, duration: 244, easing: "easeOutBack" },
            { id: "eid3770", tween: [ "transform", "${_close_button_helmet}", "scaleX", '0.9', { fromValue: '0'}], position: 21374, duration: 251 },
            { id: "eid3024", tween: [ "transform", "${_Text_yield_two}", "translateY", '91.16px', { fromValue: '91.16px'}], position: 11000, duration: 0, easing: "easeOutBack" },
            { id: "eid2646", tween: [ "transform", "${_Symbol_backlight_lights}", "translateX", '161.07px', { fromValue: '161.07px'}], position: 6740, duration: 0 },
            { id: "eid349", tween: [ "transform", "${_train_northbound_second}", "translateX", '-1026px', { fromValue: '-1321px'}], position: 4921, duration: 1828, easing: "easeOutQuad" },
            { id: "eid2306", tween: [ "transform", "${_bike_direction}", "translateX", '-61.4px', { fromValue: '459.59px'}], position: 3500, duration: 3265, easing: "easeOutQuad" },
            { id: "eid2930", tween: [ "style", "${_message_bulbble_carry}", "display", 'none', { fromValue: 'block'}], position: 9793, duration: 0, easing: "easeOutBack" },
            { id: "eid3271", tween: [ "transform", "${_bike_wear_helmet}", "translateY", '-313.14px', { fromValue: '-626.16px'}], position: 3500, duration: 3265, easing: "easeOutQuad" },
            { id: "eid3137", tween: [ "transform", "${_message_bulbble_carry2}", "scaleX", '1', { fromValue: '0'}], position: 15250, duration: 1000, easing: "easeOutBack" },
            { id: "eid2464", tween: [ "style", "${_Symbol_backlight_carry}", "opacity", '1', { fromValue: '0'}], position: 6740, duration: 240 },
            { id: "eid2302", tween: [ "transform", "${_bike_obey}", "translateX", '-31.4px', { fromValue: '489.6px'}], position: 3500, duration: 3265, easing: "easeOutQuad" },
            { id: "eid3348", tween: [ "style", "${_close_button_hazards}", "opacity", '1', { fromValue: '0'}], position: 19690, duration: 243 },
            { id: "eid3772", tween: [ "transform", "${_close_button_helmet}", "scaleY", '0.9', { fromValue: '0'}], position: 21374, duration: 251 },
            { id: "eid2639", tween: [ "transform", "${_Symbol_backlight_lights}", "translateY", '-109.84px', { fromValue: '-109.84px'}], position: 6740, duration: 0 },
            { id: "eid3206", tween: [ "style", "${_Text_lights}", "display", 'none', { fromValue: 'block'}], position: 18536, duration: 0 },
            { id: "eid3241", tween: [ "style", "${_Text_helmet}", "opacity", '1', { fromValue: '0'}], position: 21374, duration: 505, easing: "easeOutBack" },
            { id: "eid3415", tween: [ "transform", "${_Text_direction}", "translateY", '-58.19px', { fromValue: '-58.19px'}], position: 12690, duration: 0, easing: "easeOutBack" },
            { id: "eid3021", tween: [ "style", "${_Text_yield_two}", "height", '36px', { fromValue: '36px'}], position: 11000, duration: 0, easing: "easeOutBack" },
            { id: "eid2945", tween: [ "transform", "${_message_bulbble_carry}", "scaleY", '0.95', { fromValue: '0'}], position: 8240, duration: 1010, easing: "easeOutBack" },
            { id: "eid2964", tween: [ "style", "${_close_button_carry}", "opacity", '1', { fromValue: '0'}], position: 9165, duration: 244 },
            { id: "eid2154", tween: [ "style", "${_Text_attention}", "display", 'none', { fromValue: 'block'}], position: 16788, duration: 0 },
            { id: "eid805", tween: [ "transform", "${_car_sb_gray2}", "translateX", '-259.4px', { fromValue: '492.59px'}], position: 1012, duration: 5727, easing: "swing" },
            { id: "eid3479", tween: [ "transform", "${_close_button_obey}", "scaleY", '0.9', { fromValue: '0'}], position: 14400, duration: 247 },
            { id: "eid3026", tween: [ "style", "${_Text_yield_two}", "opacity", '1', { fromValue: '0'}], position: 10940, duration: 560, easing: "easeOutBack" },
            { id: "eid3463", tween: [ "transform", "${_message_bubble_obey2}", "scaleX", '0.9', { fromValue: '0'}], position: 13500, duration: 1000, easing: "easeOutBack" },
            { id: "eid3652", tween: [ "style", "${_Symbol_park_red_helmet}", "opacity", '1', { fromValue: '0'}], position: 6745, duration: 255 }         ]
      }
   }
},
"hotspot": {
   version: "0.1.6",
   build: "0.10.0.134",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   content: {
   dom: [
   {
      transform: [[-798,-181]],
      rect: [765,139,100,100],
      id: 'hotspot_03',
      opacity: 1,
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/hotspot_03.png']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${symbolSelector}": [
            ["style", "height", '35.2px'],
            ["style", "width", '33px']
         ],
         "${_hotspot_03}": [
            ["transform", "translateX", '-798px'],
            ["transform", "scaleX", '0.65'],
            ["style", "opacity", '0.75'],
            ["transform", "translateY", '-181px'],
            ["transform", "scaleY", '0.65']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 21000,
         autoPlay: true,
         labels: {
            "hotspot": 250
         },
         timeline: [
            { id: "eid1746", tween: [ "transform", "${_hotspot_03}", "scaleX", '1', { fromValue: '0.65'}], position: 250, duration: 1000, easing: "easeOutQuad" },
            { id: "eid1750", tween: [ "style", "${_hotspot_03}", "opacity", '1', { fromValue: '0.75'}], position: 250, duration: 1000, easing: "easeOutQuad" },
            { id: "eid1748", tween: [ "transform", "${_hotspot_03}", "scaleY", '1', { fromValue: '0.65'}], position: 250, duration: 1000, easing: "easeOutQuad" }         ]
      }
   }
},
"Symbol_park": {
   version: "0.1.6",
   build: "0.10.0.134",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   content: {
   dom: [
   {
      rect: [586,-49,70,52],
      id: 'le_park_spacer',
      transform: [[-585,49]],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/park_use_me_orange2.png']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_le_park_spacer}": [
            ["transform", "scaleY", '0.9'],
            ["transform", "scaleX", '0.9'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '49.54px'],
            ["transform", "translateX", '-585.57px']
         ],
         "${symbolSelector}": [
            ["style", "height", '52px'],
            ["style", "width", '70px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         labels: {
            "station": 1000
         },
         timeline: [
            { id: "eid2448", tween: [ "transform", "${_le_park_spacer}", "scaleY", '1', { fromValue: '0.9'}], position: 1000, duration: 1000, easing: "easeOutBack" },
            { id: "eid2446", tween: [ "transform", "${_le_park_spacer}", "scaleX", '1', { fromValue: '0.9'}], position: 1000, duration: 1000, easing: "easeOutBack" },
            { id: "eid2450", tween: [ "style", "${_le_park_spacer}", "opacity", '1', { fromValue: '0'}], position: 1000, duration: 1000, easing: "easeOutBack" }         ]
      }
   }
},
"Symbol_backlight": {
   version: "0.1.6",
   build: "0.10.0.134",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   content: {
   dom: [
   {
      transform: [[-423,-89],{},{},[0.7,0.7]],
      rect: [420,86,26,24],
      id: 'back_lights',
      opacity: 1,
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/back_lights.png']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_back_lights}": [
            ["transform", "translateX", '-423px'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '0.25'],
            ["transform", "translateY", '-89px'],
            ["transform", "scaleY", '0']
         ],
         "${symbolSelector}": [
            ["style", "height", '16.8px'],
            ["style", "width", '18.2px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 7000,
         autoPlay: true,
         labels: {
            "backlight": 5760
         },
         timeline: [
            { id: "eid2460", tween: [ "transform", "${_back_lights}", "scaleX", '0.45', { fromValue: '0'}], position: 5760, duration: 1240 },
            { id: "eid2458", tween: [ "style", "${_back_lights}", "opacity", '1', { fromValue: '0.25'}], position: 5760, duration: 1240 },
            { id: "eid2462", tween: [ "transform", "${_back_lights}", "scaleY", '0.45', { fromValue: '0'}], position: 5760, duration: 1240 }         ]
      }
   }
},
"Symbol_frontlight": {
   version: "0.1.6",
   build: "0.10.0.134",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   content: {
   dom: [
   {
      rect: [689,338,26,24],
      transform: [[-688,-336],{},{},[0.45,0.45]],
      id: 'frontlight2',
      opacity: 1,
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/frontlight.png']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_frontlight2}": [
            ["transform", "translateX", '-688.49px'],
            ["transform", "scaleX", '0.15'],
            ["style", "opacity", '0.69862997531891'],
            ["transform", "translateY", '-336.67px'],
            ["transform", "scaleY", '0.15']
         ],
         "${symbolSelector}": [
            ["style", "height", '24px'],
            ["style", "width", '26px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 7250,
         autoPlay: true,
         labels: {
            "frontlight": 6267
         },
         timeline: [
            { id: "eid2663", tween: [ "transform", "${_frontlight2}", "scaleY", '0.35', { fromValue: '0.15'}], position: 6267, duration: 983 },
            { id: "eid2661", tween: [ "transform", "${_frontlight2}", "scaleX", '0.35', { fromValue: '0.15'}], position: 6267, duration: 983 },
            { id: "eid2665", tween: [ "style", "${_frontlight2}", "opacity", '1', { fromValue: '0.69862997531891'}], position: 6267, duration: 983 }         ]
      }
   }
},
"Symbol_blick": {
   version: "0.1.6",
   build: "0.10.0.134",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   content: {
   dom: [
   {
      type: 'image',
      id: 'park_white',
      rect: [308,-6,70,52],
      transform: [[-307,7]],
      fill: ['rgba(0,0,0,0)','images/park_white.png']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${symbolSelector}": [
            ["style", "height", '50px'],
            ["style", "width", '69px']
         ],
         "${_park_white}": [
            ["transform", "translateX", '-307.15px'],
            ["transform", "scaleX", '0.9'],
            ["style", "opacity", '0.75'],
            ["transform", "translateY", '7.95px'],
            ["transform", "scaleY", '0.9']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2250,
         autoPlay: true,
         timeline: [
            { id: "eid3503", tween: [ "style", "${_park_white}", "opacity", '1', { fromValue: '0.75'}], position: 1000, duration: 1250 },
            { id: "eid3505", tween: [ "transform", "${_park_white}", "scaleX", '1', { fromValue: '0.9'}], position: 1000, duration: 1250 },
            { id: "eid3511", tween: [ "transform", "${_park_white}", "scaleY", '1', { fromValue: '0.9'}], position: 1000, duration: 1250 }         ]
      }
   }
},
"Symbol_park_orange": {
   version: "0.1.6",
   build: "0.10.0.134",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   content: {
   dom: [
   {
      rect: [1,1,70,52],
      id: 'park_use_me_orange',
      transform: {},
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/park_use_me_blue.png']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_park_use_me_orange}": [
            ["transform", "scaleX", '0.9'],
            ["style", "opacity", '0'],
            ["transform", "scaleY", '0.9']
         ],
         "${symbolSelector}": [
            ["style", "height", '50px'],
            ["style", "width", '69px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         labels: {
            "orangestart": 1000
         },
         timeline: [
            { id: "eid3645", tween: [ "transform", "${_park_use_me_orange}", "scaleX", '1', { fromValue: '0.9'}], position: 1000, duration: 1000 },
            { id: "eid3647", tween: [ "transform", "${_park_use_me_orange}", "scaleY", '1', { fromValue: '0.9'}], position: 1000, duration: 1000 },
            { id: "eid3643", tween: [ "style", "${_park_use_me_orange}", "opacity", '1', { fromValue: '0'}], position: 1000, duration: 1000 }         ]
      }
   }
},
"Symbol_park_red": {
   version: "0.1.6",
   build: "0.10.0.134",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   content: {
   dom: [
   {
      rect: [34,25,70,52],
      id: 'park_use_me_red2',
      transform: [[-33,-24]],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/park_use_me_blue.png']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_park_use_me_red2}": [
            ["transform", "scaleY", '0.9'],
            ["transform", "scaleX", '0.9'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-24.02px'],
            ["transform", "translateX", '-33.55px']
         ],
         "${symbolSelector}": [
            ["style", "height", '50px'],
            ["style", "width", '69px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         labels: {
            "redstart": 990
         },
         timeline: [
            { id: "eid3634", tween: [ "transform", "${_park_use_me_red2}", "scaleY", '1', { fromValue: '0.9'}], position: 990, duration: 1010 },
            { id: "eid3632", tween: [ "transform", "${_park_use_me_red2}", "scaleX", '1', { fromValue: '0.9'}], position: 990, duration: 1010 },
            { id: "eid3636", tween: [ "style", "${_park_use_me_red2}", "opacity", '1', { fromValue: '0'}], position: 990, duration: 1010 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-1752384041");
